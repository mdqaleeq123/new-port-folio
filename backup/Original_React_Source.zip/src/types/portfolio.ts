export interface SkillItem {
  name: string;
  category: 'programming' | 'tools' | 'it_support' | 'engineering' | 'productivity';
  description: string;
  highlight?: boolean;
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  location: string;
  period: string;
  startDate: string;
  endDate: string;
  summary: string;
  responsibilities: string[];
  skillsUsed: string[];
  toolsUsed: string[];
  category: 'operations' | 'research';
}

export interface ProjectItem {
  id: string;
  title: string;
  subtitle: string;
  institution: string;
  period?: string;
  description: string;
  problem: string;
  methodology: string[];
  technologies: string[];
  highlights: string[];
  isFeatured: boolean;
  status: 'Completed' | 'Template Slot';
}

export interface EducationItem {
  degree: string;
  field: string;
  institution: string;
  location: string;
  period: string;
  honours?: string;
  highlights: string[];
}

export interface LanguageItem {
  language: string;
  proficiency: string;
  levelCode: string;
  notes: string;
}

export interface StrengthItem {
  title: string;
  description: string;
}
