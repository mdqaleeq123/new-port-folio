import {
  SkillItem,
  ExperienceItem,
  ProjectItem,
  EducationItem,
  LanguageItem,
  StrengthItem,
} from '../types/portfolio';

export const PERSONAL_INFO = {
  name: 'Abdul Qaleeq Mohammed',
  titles: [
    'Python Developer',
    'IT Support Engineer',
    'Technical Operations Specialist',
  ],
  tagline:
    'Engineering graduate with a strong analytical foundation in Python scripting, IT systems support, technical operations, and quantitative data modeling. Passionate about solving technical problems, improving operational efficiency, and building reliable technology-driven solutions.',
  fullSummary:
    "Results-driven Master's graduate with a strong analytical foundation in engineering frameworks, quantitative data modeling, and IT systems integration. Experienced in system operational monitoring, automated data handling, and technical troubleshooting. Proficient in Python, scripting logic, AutoCAD, MS Project, and project data management. Dedicated to streamlining operations and resolving complex technical issues across modern IT infrastructures.",
  email: 'mdqaleeq123@gmail.com',
  whatsapp: '+371 25780055',
  whatsappRaw: '37125780055',
  location: 'Riga, Latvia',
  timezone: 'EET (UTC+2 / UTC+3)',
  avatarUrl: '/assets/aistudio/abdul_qaleeq_portrait.jpg',
  resumePreviewImg: '/assets/aistudio/resume_page_1.png',
  resumeUrl: '/assets/aistudio/Abdul_Qaleeq_Mohammed_-_Resume_57bf1a47.pdf',
  resumeFileName: 'Abdul_Qaleeq_Mohammed_Resume.pdf',
};

export const SKILLS: SkillItem[] = [
  // Programming and Web Technologies
  {
    name: 'Python',
    category: 'programming',
    description: 'Scripting automation, quantitative data modeling, algorithmic logic, and operational tooling.',
    highlight: true,
  },
  {
    name: 'SQL (Data Querying)',
    category: 'programming',
    description: 'Relational data querying, record extraction, operational data management, and reporting datasets.',
    highlight: true,
  },
  {
    name: 'HTML & CSS',
    category: 'programming',
    description: 'Structured web markup, styling fundamentals, and responsive interface foundations.',
  },
  {
    name: 'Scripting Automation',
    category: 'programming',
    description: 'Automating repetitive data handling tasks, scheduled checks, and operational script flows.',
    highlight: true,
  },
  {
    name: 'Logic Flow & Algorithms',
    category: 'programming',
    description: 'Step-by-step conditional workflows, algorithmic problem breakdown, and process optimization.',
  },

  // Developer Tools
  {
    name: 'Visual Studio Code',
    category: 'tools',
    description: 'Primary IDE for Python scripting, debugging, extension ecosystem, and code navigation.',
  },
  {
    name: 'Git',
    category: 'tools',
    description: 'Version control, branch management, code tracking, and collaborative repositories.',
  },
  {
    name: 'GitHub',
    category: 'tools',
    description: 'Repository hosting, commit tracking, project release management, and version documentation.',
  },

  // IT Support and Operations
  {
    name: 'Technical Troubleshooting',
    category: 'it_support',
    description: 'Diagnosing hardware anomalies, resolving live software runtime errors, and rapid recovery.',
    highlight: true,
  },
  {
    name: 'System Operational Monitoring',
    category: 'it_support',
    description: 'Continuous surveillance of live digital systems to maintain uptime and performance integrity.',
    highlight: true,
  },
  {
    name: 'System Status Checks (SOPs)',
    category: 'it_support',
    description: 'Executing strict technical Standard Operating Procedures to verify system availability.',
    highlight: true,
  },
  {
    name: 'Operational Logging',
    category: 'it_support',
    description: 'Maintaining meticulous shift logs, error traces, and status documentation for technical review.',
  },
  {
    name: 'Technical Issue Escalation',
    category: 'it_support',
    description: 'Systematic handoff of tier-2 bugs and infrastructure incidents to engineering and network leads.',
  },
  {
    name: 'IT Systems Support',
    category: 'it_support',
    description: 'Hardware/software operational reliability, digital workflow continuity, and end-to-end support.',
  },

  // Engineering & Project Management
  {
    name: 'AutoCAD',
    category: 'engineering',
    description: 'Technical drafting, structural workflow layouts, spatial modeling, and system design plans.',
  },
  {
    name: 'MS Project',
    category: 'engineering',
    description: 'Gantt chart scheduling, critical path modeling, operational timeline tracking, and milestones.',
  },
  {
    name: 'Primavera P6',
    category: 'engineering',
    description: 'Enterprise project planning, resource scheduling, process modeling, and timeline analysis.',
  },
  {
    name: 'Process Modeling',
    category: 'engineering',
    description: 'Mapping system workflows, organizational dynamics, and operational bottleneck reduction.',
  },
  {
    name: 'Project Data Management',
    category: 'engineering',
    description: 'Structured collation, validation, and control of technical project datasets.',
  },

  // Productivity & Data Analysis
  {
    name: 'Microsoft Excel (Data Analysis)',
    category: 'productivity',
    description: 'Quantitative analytical formulas, pivot tables, dataset modeling, and performance calculations.',
    highlight: true,
  },
  {
    name: 'Microsoft Word',
    category: 'productivity',
    description: 'Technical documentation, SOP drafting, structured reports, and academic research writing.',
  },
  {
    name: 'Microsoft PowerPoint',
    category: 'productivity',
    description: 'Technical presentations, stakeholder reports, research briefings, and workflow diagrams.',
  },
];

export const EXPERIENCES: ExperienceItem[] = [
  {
    id: 'euro-live',
    role: 'Technical Operations Support Representative',
    company: 'Euro Live Technologies',
    location: 'Riga, Latvia',
    period: 'Jan 2020 – May 2021',
    startDate: 'Jan 2020',
    endDate: 'May 2021',
    summary:
      'Responsible for live digital hardware and software surveillance, incident troubleshooting, and cross-functional technical escalation in a mission-critical 24/7 operating environment.',
    responsibilities: [
      'Monitored live digital hardware and software systems in real time to ensure uninterrupted operational continuity.',
      'Resolved realtime technical errors and operational disruptions swiftly, adhering to established escalation matrix protocols.',
      'Conducted rigorous system status checks according to established technical Standard Operating Procedures (SOPs).',
      'Collaborated closely with technical leads and network operators to minimize system downtime and enhance service reliability.',
      'Maintained precise operational logs, event timelines, and systematically escalated technical bugs to tier-2 systems support teams.',
    ],
    skillsUsed: [
      'Technical Troubleshooting',
      'System Operational Monitoring',
      'System Status Checks (SOPs)',
      'Operational Logging',
      'Tier-2 Technical Bug Escalation',
      'Incident Triage',
    ],
    toolsUsed: ['Live Monitoring Consoles', 'Hardware Diagnostic Tools', 'Standard Operating Procedures', 'Internal Incident Logs'],
    category: 'operations',
  },
  {
    id: 'rtu-research',
    role: 'System Analysis & Data Project Researcher',
    company: 'RTU Management Research',
    location: 'Riga, Latvia',
    period: 'Aug 2019 – Jan 2021',
    startDate: 'Aug 2019',
    endDate: 'Jan 2021',
    summary:
      'Conducted advanced systems analysis and quantitative management research, building structured models to evaluate management systems across Latvian industry sectors.',
    responsibilities: [
      'Engineered quantitative analytical models to evaluate organization management systems across multiple Latvian industry sectors.',
      'Utilized AutoCAD, MS Project, and Primavera P6 for complex process modeling, structural workflows, and timeline optimization.',
      'Formulated structured operational matrices to identify system bottlenecks and propose data-backed improvements.',
      'Conducted technical data collation, verification, and synthesized research findings for engineering academic publications.',
    ],
    skillsUsed: [
      'Quantitative Analytical Modeling',
      'Process Modeling',
      'Project Scheduling',
      'Structural Workflows',
      'Systems Analysis',
    ],
    toolsUsed: ['AutoCAD', 'MS Project', 'Primavera P6', 'Advanced Excel Data Modeling'],
    category: 'research',
  },
];

export const PROJECTS: ProjectItem[] = [
  {
    id: 'msc-thesis',
    title: 'Quantitative Management System Optimization',
    subtitle: "Master's Thesis Project",
    institution: 'Riga Technical University (RTU)',
    period: '2020 – 2021',
    isFeatured: true,
    status: 'Completed',
    description:
      'Developed a structured framework to model, measure, and streamline operational efficiency for technical management systems.',
    problem:
      'Modern technical operations and construction management infrastructures frequently experience workflow fragmentation and latency due to non-standardized process monitoring and uncoordinated resource handoffs.',
    methodology: [
      'Formulated a quantitative mathematical model establishing standardized efficiency parameters across technical systems.',
      'Used Python scripting and data analysis routines to process operational metrics, evaluate task dependencies, and simulate workflow scenarios.',
      'Integrated structural process modeling principles adapted from engineering scheduling software (MS Project & Primavera P6).',
      'Synthesized empirical findings into a structured technical thesis defended with 1st Class Honours at RTU.',
    ],
    technologies: [
      'Python Scripting',
      'System Optimization',
      'Data Analytics',
      'Technical Modeling',
      'Process Flow Modeling',
      'Quantitative Analysis',
    ],
    highlights: [
      'Awarded 1st Class Honours distinction by Riga Technical University faculty.',
      'Established measurable operational efficiency parameters for complex organizational workflows.',
      'Demonstrated practical bridge between quantitative Python analytics and engineering management.',
    ],
  },
  {
    id: 'future-python-automation',
    title: 'Automated System Health & Operational Log Analyzer',
    subtitle: 'Python Scripting & Monitoring Portfolio Implementation Slot',
    institution: 'Open for Demonstration & Code Review',
    isFeatured: false,
    status: 'Template Slot',
    description:
      'Automated Python utility framework designed to parse real-time IT system event logs, trigger automated SOP health-check passes, and output structured incident metrics.',
    problem:
      'Manual log auditing and status verification in live IT operations introduces human latency and risks overlooking transient error codes.',
    methodology: [
      'Regex-based error code extraction and incident classification from live server logs.',
      'Automated generation of daily operational uptime summaries and tier-2 escalation packets.',
      'Lightweight SQL data ingestion for trend analysis across monitored hardware nodes.',
    ],
    technologies: [
      'Python',
      'Regex & Log Parsing',
      'SQL Data Querying',
      'SOP Automation',
    ],
    highlights: [
      'Directly modeled after live operations experience at Euro Live Technologies.',
      'Ready for customized GitHub repository linking and live execution demonstration.',
    ],
  },
  {
    id: 'future-sql-reporting',
    title: 'Operational Data Query & Process Scheduling Engine',
    subtitle: 'Data Analytics & Workflow Automation Slot',
    institution: 'Open for Demonstration & Code Review',
    isFeatured: false,
    status: 'Template Slot',
    description:
      'Data pipeline and query automation project synthesizing multi-source operational metrics into structured reporting tables and scheduling benchmarks.',
    problem:
      'Cross-departmental managers require streamlined visibility into milestone delays and resource utilization without complex manual spreadsheet manipulation.',
    methodology: [
      'Structured SQL querying across operational databases to isolate bottleneck timestamps.',
      'Scripted data transformation pipeline aligning milestone timelines with Primavera P6 standards.',
      'Automated export into clean tabular summaries for engineering management review.',
    ],
    technologies: [
      'SQL',
      'Python Data Handling',
      'MS Excel Data Analysis',
      'Process Scheduling',
    ],
    highlights: [
      'Combines quantitative data querying with engineering project management rigor.',
      'Configured with customizable schema templates for employer-specific demonstrations.',
    ],
  },
];

export const EDUCATION: EducationItem[] = [
  {
    degree: 'MSc in Civil Construction & Management',
    field: 'Civil Construction & Management',
    institution: 'Riga Technical University (RTU)',
    location: 'Riga, Latvia',
    period: 'Aug 2019 – Jan 2021',
    honours: '1st Class Honours',
    highlights: [
      'Graduated with 1st Class Honours, achieving top-tier academic distinction.',
      'Focused on quantitative management modeling, structural process optimization, and project scheduling systems.',
      'Mastered advanced engineering software including AutoCAD, MS Project, and Primavera P6 for complex multi-phase systems.',
      'Defended thesis: "Quantitative Management System Optimization", bridging data analytics and operational engineering.',
    ],
  },
  {
    degree: 'B.Tech in Civil Engineering',
    field: 'Civil Engineering',
    institution: 'Al Habeeb College of Engineering and Technology',
    location: 'Hyderabad, India',
    period: 'May 2014 – May 2019',
    highlights: [
      'Built a rigorous foundation in engineering mathematics, structural analysis, and quantitative problem solving.',
      'Developed core analytical discipline, logical deduction, and systematic methodology for complex problem troubleshooting.',
      'Hands-on coursework in engineering design, project planning, materials evaluation, and technical reporting.',
    ],
  },
];

export const LANGUAGES: LanguageItem[] = [
  {
    language: 'English',
    proficiency: 'Proficient',
    levelCode: 'C2 / C1',
    notes: 'Full professional working and academic proficiency; completed Master of Science degree in English medium with 1st Class Honours.',
  },
  {
    language: 'Hindi',
    proficiency: 'Native',
    levelCode: 'Native Speaker',
    notes: 'Native verbal and written fluency, enabling natural multicultural communication.',
  },
  {
    language: 'Latvian',
    proficiency: 'Basic',
    levelCode: 'A1',
    notes: 'Basic conversational and everyday operational familiarity acquired through residency and graduate study in Riga, Latvia.',
  },
];

export const STRENGTHS: StrengthItem[] = [
  {
    title: 'Critical Thinking',
    description:
      'Ability to evaluate technical system behavior objectively, question assumptions, identify root causes, and evaluate operational trade-offs under real-time constraints.',
  },
  {
    title: 'Problem Solving',
    description:
      'Structured diagnostic mindset developed through engineering training; systematically decomposing unexpected disruptions into solvable components.',
  },
  {
    title: 'Analytical Reasoning',
    description:
      'Translating messy operational data and complex management frameworks into clear, quantitative mathematical models and actionable conclusions.',
  },
  {
    title: 'Media & Communication',
    description:
      'Articulating technical incidents, SOP updates, and escalation logs clearly to technical leads, network operators, and non-technical stakeholders.',
  },
  {
    title: 'Process Scheduling',
    description:
      'Expertise in milestone dependencies, critical path sequencing, and timeline tracking using MS Project, Primavera P6, and operational SOPs.',
  },
];
