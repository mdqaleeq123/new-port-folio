/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Skills } from './components/Skills';
import { Experience } from './components/Experience';
import { Projects } from './components/Projects';
import { Education } from './components/Education';
import { LanguagesStrengths } from './components/LanguagesStrengths';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ResumeModal } from './components/ResumeModal';
import { InboxModal } from './components/InboxModal';
import { SourceCodeModal } from './components/SourceCodeModal';

export default function App() {
  const [isResumeModalOpen, setIsResumeModalOpen] = useState(false);
  const [isInboxModalOpen, setIsInboxModalOpen] = useState(false);
  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#080D1A] text-slate-200 selection:bg-blue-600 selection:text-white flex flex-col font-sans">
      {/* Top Navigation */}
      <Navbar
        onOpenResumeModal={() => setIsResumeModalOpen(true)}
        onOpenInboxModal={() => setIsInboxModalOpen(true)}
        onOpenCodeModal={() => setIsCodeModalOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-grow">
        <Hero onOpenResumeModal={() => setIsResumeModalOpen(true)} />
        <About />
        <Skills />
        <Experience />
        <Projects />
        <Education />
        <LanguagesStrengths />
        <Contact onOpenInboxModal={() => setIsInboxModalOpen(true)} />
      </main>

      {/* Footer */}
      <Footer
        onOpenResumeModal={() => setIsResumeModalOpen(true)}
        onOpenInboxModal={() => setIsInboxModalOpen(true)}
        onOpenCodeModal={() => setIsCodeModalOpen(true)}
      />

      {/* Resume Document Viewer Modal */}
      <ResumeModal
        isOpen={isResumeModalOpen}
        onClose={() => setIsResumeModalOpen(false)}
      />

      {/* Recruiter Inquiries Inbox Modal */}
      <InboxModal
        isOpen={isInboxModalOpen}
        onClose={() => setIsInboxModalOpen(false)}
        onOpenCodeModal={() => setIsCodeModalOpen(true)}
      />

      {/* Download Code & PC Setup Guide Modal */}
      <SourceCodeModal
        isOpen={isCodeModalOpen}
        onClose={() => setIsCodeModalOpen(false)}
      />
    </div>
  );
}
