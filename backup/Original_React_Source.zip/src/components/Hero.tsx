import React, { useState } from 'react';
import {
  Download,
  Terminal,
  Play,
  RotateCcw,
  CheckCircle2,
  Database,
  Cpu,
  ShieldCheck,
  FileText,
  Mail,
  ChevronRight,
  Sliders,
  MapPin,
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { ProfilePhoto } from './ProfilePhoto';
import { downloadResumePdf } from '../utils/portfolioUtils';

interface HeroProps {
  onOpenResumeModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenResumeModal }) => {
  const [activeTab, setActiveTab] = useState<'monitor' | 'optimizer' | 'sql'>('monitor');
  const [isRunningCheck, setIsRunningCheck] = useState(false);
  const [checkPassed, setCheckPassed] = useState(true);
  const [systemUptime] = useState(99.98);
  const [activeNodes] = useState(24);
  const [optimizationWeight, setOptimizationWeight] = useState(75);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleRunCheck = () => {
    setIsRunningCheck(true);
    setTimeout(() => {
      setIsRunningCheck(false);
      setCheckPassed(true);
    }, 600);
  };

  const handleDownloadCV = async () => {
    setIsDownloading(true);
    await downloadResumePdf();
    setIsDownloading(false);
  };

  const calculatedEfficiency = Math.min(99.4, (82 + (optimizationWeight * 0.18))).toFixed(1);

  return (
    <section id="home" className="relative pt-24 pb-16 lg:pt-32 lg:pb-24 overflow-hidden tech-grid-pattern">
      {/* Background ambient lighting */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute top-1/3 -right-20 w-[400px] h-[350px] bg-cyan-500/8 rounded-full blur-[120px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Main 2-column split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-start">
          
          {/* Left Column: Full-Frame Profile Picture, Typographic Hierarchy, and Narrative */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Profile Picture & Executive Headline Lockup */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 lg:gap-7">
              {/* Full-Frame Portrait: Increased width & height displaying complete photo */}
              <div className="flex flex-col items-center gap-2 shrink-0">
                <ProfilePhoto variant="hero" className="shadow-2xl ring-2 ring-blue-500/30" />
                <div className="text-[11px] font-mono text-cyan-400 flex items-center gap-1.5 pt-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span>Verified Profile · Riga, Latvia</span>
                </div>
              </div>

              {/* Title & Introduction Block */}
              <div className="space-y-3 flex-1 text-center sm:text-left min-w-0">
                {/* Unboxed Metadata Kicker (Zero-pill discipline) */}
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs font-mono text-cyan-400 font-medium">
                  <span>Python Scripting</span>
                  <span className="text-slate-600" aria-hidden="true">/</span>
                  <span>IT Systems Support</span>
                  <span className="text-slate-600" aria-hidden="true">/</span>
                  <span>Operations</span>
                </div>

                {/* Dominant Headline */}
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-[1.2]">
                  {PERSONAL_INFO.name}
                </h1>

                {/* Verified Professional Title */}
                <p className="text-sm sm:text-base font-semibold text-blue-400 leading-snug">
                  Python Developer | IT Support Engineer | Technical Operations Specialist
                </p>

                {/* Concise Introduction from CV */}
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal pt-1">
                  {PERSONAL_INFO.tagline}
                </p>

                {/* Quick Academic & Role Highlights */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-xs text-slate-400">
                  <div className="flex items-center gap-2 justify-center sm:justify-start">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>MSc 1st Class Honours</span>
                  </div>
                  <div className="flex items-center gap-2 justify-center sm:justify-start">
                    <Cpu className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span>Euro Live Technologies</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons Row */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 pt-2">
              <a
                href="#projects"
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-sm hover:shadow-blue-500/25 transition-all inline-flex items-center gap-2 whitespace-nowrap"
              >
                <span>Explore My Work</span>
                <ChevronRight className="w-4 h-4" />
              </a>

              <a
                href="#contact"
                className="px-5 py-2.5 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 text-xs sm:text-sm font-semibold rounded-lg border border-slate-700 hover:border-slate-600 transition-all inline-flex items-center gap-2 whitespace-nowrap"
              >
                <Mail className="w-4 h-4 text-blue-400" />
                <span>Contact Me</span>
              </a>

              <button
                onClick={onOpenResumeModal}
                className="px-4 py-2.5 bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white text-xs sm:text-sm font-medium rounded-lg border border-slate-800 transition-all inline-flex items-center gap-2 whitespace-nowrap"
              >
                <FileText className="w-4 h-4 text-cyan-400" />
                <span>View CV Document</span>
              </button>

              <button
                onClick={handleDownloadCV}
                disabled={isDownloading}
                className="px-4 py-2.5 text-xs sm:text-sm font-medium text-slate-300 hover:text-blue-400 transition-colors inline-flex items-center gap-1.5 underline underline-offset-4"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isDownloading ? 'Downloading...' : 'Download PDF'}</span>
              </button>
            </div>
          </div>

          {/* Right Column: Sophisticated Technical Operations Console */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl bg-[#0B1120] border border-slate-800 shadow-2xl overflow-hidden">
              
              {/* Terminal Window Header */}
              <div className="flex items-center justify-between px-4 py-3 bg-[#070C18] border-b border-slate-800/90">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  <span className="ml-2 text-xs font-mono text-slate-400 font-medium">
                    tech_ops_engine v2.6
                  </span>
                </div>
                <div className="text-[11px] font-mono text-slate-500">
                  Riga · GMT+2
                </div>
              </div>

              {/* Segmented Code Tabs */}
              <div className="flex items-center gap-1 px-3 pt-2 bg-[#090E1B] border-b border-slate-800/60 overflow-x-auto">
                <button
                  onClick={() => setActiveTab('monitor')}
                  className={`px-3 py-1.5 text-xs font-mono font-medium rounded-t-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'monitor'
                      ? 'bg-[#0B1120] text-cyan-400 border-t border-x border-slate-800'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>ops_monitor.py</span>
                </button>

                <button
                  onClick={() => setActiveTab('optimizer')}
                  className={`px-3 py-1.5 text-xs font-mono font-medium rounded-t-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'optimizer'
                      ? 'bg-[#0B1120] text-blue-400 border-t border-x border-slate-800'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>rtu_optimizer.py</span>
                </button>

                <button
                  onClick={() => setActiveTab('sql')}
                  className={`px-3 py-1.5 text-xs font-mono font-medium rounded-t-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'sql'
                      ? 'bg-[#0B1120] text-emerald-400 border-t border-x border-slate-800'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>system_logs.sql</span>
                </button>
              </div>

              {/* Terminal Code Body */}
              <div className="p-4 font-mono text-xs text-slate-300 space-y-3 min-h-[260px] bg-[#0B1120]">
                {activeTab === 'monitor' && (
                  <div className="space-y-2">
                    <div className="text-slate-500"># Euro Live Tech: Live Digital Hardware & Software SOP Verification</div>
                    <div className="text-slate-300">
                      <span className="text-purple-400">import</span> time, telemetry, logging
                    </div>
                    <div className="text-slate-300">
                      <span className="text-blue-400">class</span> <span className="text-amber-300">TechOperationsMonitor</span>:
                    </div>
                    <div className="pl-4 text-slate-300">
                      <span className="text-blue-400">def</span> <span className="text-amber-300">verify_live_status</span>(self, node_pool):
                    </div>
                    <div className="pl-8 text-slate-400">
                      checks = [sop.execute_check(n) for n in node_pool]
                    </div>
                    <div className="pl-8 text-cyan-300">
                      <span className="text-purple-400">if</span> all(c.status == <span className="text-emerald-400">'NOMINAL'</span> for c in checks):
                    </div>
                    <div className="pl-12 text-slate-300">
                      <span className="text-purple-400">return</span> logging.log_shift_event(<span className="text-emerald-400">'SOP-PASSED'</span>)
                    </div>
                    <div className="pl-8 text-slate-400">
                      <span className="text-purple-400">else</span>: escalate_to_tier2(checks.errors)
                    </div>

                    <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        <span className="text-emerald-400 font-semibold">Nodes: {activeNodes}/24 Live</span>
                        <span className="text-slate-500">·</span>
                        <span className="text-slate-400">Uptime: {systemUptime}%</span>
                      </div>
                      <button
                        onClick={handleRunCheck}
                        disabled={isRunningCheck}
                        className="px-2.5 py-1 bg-cyan-950/70 hover:bg-cyan-900 border border-cyan-800/70 text-cyan-300 rounded text-[11px] font-mono inline-flex items-center gap-1 transition-colors disabled:opacity-50"
                      >
                        {isRunningCheck ? (
                          <RotateCcw className="w-3 h-3 animate-spin" />
                        ) : (
                          <Play className="w-3 h-3" />
                        )}
                        <span>{isRunningCheck ? 'Checking...' : 'Run SOP Check'}</span>
                      </button>
                    </div>

                    {checkPassed && (
                      <div className="p-2 rounded bg-emerald-950/30 border border-emerald-800/40 text-[11px] text-emerald-300 flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>SOP Compliance Verified: 0 live hardware/software errors.</span>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'optimizer' && (
                  <div className="space-y-2">
                    <div className="text-slate-500"># RTU Master Thesis: Quantitative Operational Modeling</div>
                    <div className="text-slate-300">
                      <span className="text-purple-400">def</span> <span className="text-amber-300">calculate_management_efficiency</span>(load_factor, scheduling_path):
                    </div>
                    <div className="pl-4 text-slate-400">
                      # Mathematical quantitative framework across sectors
                    </div>
                    <div className="pl-4 text-slate-300">
                      bottleneck_coefficient = (load_factor * 0.18) + 82.0
                    </div>
                    <div className="pl-4 text-cyan-300">
                      optimized_throughput = min(99.4, bottleneck_coefficient)
                    </div>
                    <div className="pl-4 text-slate-300">
                      <span className="text-purple-400">return</span> round(optimized_throughput, 2)
                    </div>

                    <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400">Workflow Parameter Weight: {optimizationWeight}%</span>
                        <span className="text-blue-400 font-bold">Efficiency Score: {calculatedEfficiency}%</span>
                      </div>
                      <input
                        type="range"
                        min="20"
                        max="100"
                        value={optimizationWeight}
                        onChange={(e) => setOptimizationWeight(Number(e.target.value))}
                        className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                        aria-label="Optimization Parameter Slider"
                      />
                      <div className="text-[11px] text-slate-400">
                        Adjust slider to calculate dynamic operational efficiency output.
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'sql' && (
                  <div className="space-y-2">
                    <div className="text-slate-500">-- Operational Logging & Tier-2 Escalation Query</div>
                    <div className="text-blue-400">
                      SELECT <span className="text-slate-300">event_timestamp, subsystem_id, error_code, escalation_status</span>
                    </div>
                    <div className="text-blue-400">
                      FROM <span className="text-amber-300">production_operational_logs</span>
                    </div>
                    <div className="text-blue-400">
                      WHERE <span className="text-slate-300">severity_level = </span><span className="text-emerald-400">'TIER_2_ESCALATED'</span>
                    </div>
                    <div className="text-blue-400">
                      ORDER BY <span className="text-slate-300">event_timestamp DESC</span>
                    </div>
                    <div className="text-blue-400">
                      LIMIT <span className="text-purple-400">5</span>;
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                      <div className="text-slate-500 font-medium">[OUTPUT STREAM]</div>
                      <div className="text-slate-300">2021-05-18 04:12:09 | NODE-09 | ERR_NET_TIMEOUT | RESOLVED_BY_SOP</div>
                      <div className="text-slate-300">2021-05-17 22:45:11 | NODE-02 | ERR_MEM_SPIKE | TIER2_ACKNOWLEDGED</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Status bar */}
              <div className="px-4 py-2 bg-[#070C18] border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                <div>Python 3.11 · Bash · Git</div>
                <div className="text-cyan-400">Active Technical Profile</div>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width Quantitative KPI Strip */}
        <div className="mt-14 pt-8 border-t border-slate-800/80 grid grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="space-y-1">
            <div className="text-2xl sm:text-3xl font-bold text-white tracking-tight tabular-nums">
              1st Class
            </div>
            <div className="text-xs font-medium text-blue-400 uppercase tracking-wider">
              Academic Honours
            </div>
            <p className="text-xs text-slate-400">
              Riga Technical University MSc in Civil Construction & Management
            </p>
          </div>

          <div className="space-y-1">
            <div className="text-2xl sm:text-3xl font-bold text-white tracking-tight tabular-nums">
              24/7 Live
            </div>
            <div className="text-xs font-medium text-cyan-400 uppercase tracking-wider">
              Systems Operations
            </div>
            <p className="text-xs text-slate-400">
              Euro Live Technologies: Digital hardware & software monitoring
            </p>
          </div>

          <div className="space-y-1">
            <div className="text-2xl sm:text-3xl font-bold text-white tracking-tight tabular-nums">
              2 Degrees
            </div>
            <div className="text-xs font-medium text-indigo-400 uppercase tracking-wider">
              Engineering Foundation
            </div>
            <p className="text-xs text-slate-400">
              Master of Science (RTU, Latvia) + B.Tech (Civil Engineering, India)
            </p>
          </div>

          <div className="space-y-1">
            <div className="text-2xl sm:text-3xl font-bold text-white tracking-tight tabular-nums">
              C2 / C1
            </div>
            <div className="text-xs font-medium text-emerald-400 uppercase tracking-wider">
              English Proficiency
            </div>
            <p className="text-xs text-slate-400">
              Full professional working & academic proficiency, plus Hindi & Latvian
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
