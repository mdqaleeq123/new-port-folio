import React from 'react';
import {
  GraduationCap,
  Award,
  Calendar,
  MapPin,
  CheckCircle2,
  BookOpen,
} from 'lucide-react';
import { EDUCATION } from '../data/portfolioData';

export const Education: React.FC = () => {
  return (
    <section id="education" className="py-20 lg:py-28 bg-[#070B14] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 space-y-3">
          <div className="text-xs font-mono text-blue-400 font-medium">
            Academic Qualifications & Credentials
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
            Education & Degrees
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Rigorous engineering education providing quantitative reasoning, systematic process analysis, and technical problem-solving principles.
          </p>
        </div>

        {/* Education Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {EDUCATION.map((edu, index) => (
            <div
              key={edu.degree}
              className="p-6 sm:p-8 rounded-2xl bg-[#0B1120] border border-slate-800 hover:border-slate-700 transition-all space-y-6 flex flex-col justify-between"
            >
              <div className="space-y-4">
                
                {/* Degree Header & Honours */}
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-blue-600/10 border border-blue-500/30 text-blue-400">
                      <GraduationCap className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono text-slate-400">
                      {index === 0 ? "Master's Degree" : "Bachelor's Degree"}
                    </span>
                  </div>

                  {edu.honours && (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 text-xs font-semibold">
                      <Award className="w-3.5 h-3.5" />
                      <span>{edu.honours}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-1.5">
                  <h3 className="text-lg sm:text-xl font-bold text-white">
                    {edu.degree}
                  </h3>
                  <div className="text-sm font-medium text-blue-400">
                    {edu.institution}
                  </div>
                </div>

                {/* Metadata Row */}
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-500" />
                    <span>{edu.location}</span>
                  </div>
                  <span className="text-slate-700" aria-hidden="true">·</span>
                  <div className="flex items-center gap-1 font-mono">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>{edu.period}</span>
                  </div>
                </div>

                {/* Highlights */}
                <div className="space-y-2 pt-2">
                  <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Core Academic Highlights:</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {edu.highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                        <span className="leading-relaxed">{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

              </div>

              {/* Bottom Verification Note */}
              <div className="pt-4 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono">
                Verified Degree Credential · Transcripts Available
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
