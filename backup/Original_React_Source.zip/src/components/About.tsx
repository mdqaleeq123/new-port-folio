import React, { useState } from 'react';
import {
  GraduationCap,
  Cpu,
  Code2,
  CalendarCheck,
  CheckCircle,
  FileCheck2,
  Workflow,
  Sparkles,
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { ProfilePhoto } from './ProfilePhoto';

export const About: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'engineering' | 'it_ops' | 'tools'>('overview');

  return (
    <section id="about" className="py-20 lg:py-28 bg-[#070B14] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 space-y-3">
          <div className="text-xs font-mono text-blue-400 font-medium">
            Background & Engineering Profile
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
            About Me
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Bridging analytical engineering rigor with hands-on IT operations, real-time hardware/software troubleshooting, and Python automation.
          </p>
        </div>

        {/* Narrative & Interactive Focus Switcher */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Core Narrative & Quote */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Primary Biography with Profile Card */}
            <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-6 sm:p-8 space-y-5 text-slate-300 text-sm sm:text-base leading-relaxed">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 pb-5 border-b border-slate-800/80">
                <ProfilePhoto variant="about" className="shrink-0 shadow-lg" />
                <div className="space-y-1.5">
                  <div className="text-white font-bold text-lg sm:text-xl">
                    {PERSONAL_INFO.name}
                  </div>
                  <div className="text-xs text-blue-400 font-medium">
                    MSc Civil Construction & Management (1st Class Honours)
                  </div>
                  <div className="text-xs text-slate-400">
                    Riga Technical University · B.Tech Civil Engineering
                  </div>
                </div>
              </div>

              <p>
                I hold a <strong className="text-white font-semibold">Master of Science in Civil Construction & Management with 1st Class Honours</strong> from <strong className="text-white font-semibold">Riga Technical University</strong> in Latvia, preceded by a <strong className="text-white font-semibold">Bachelor of Technology in Civil Engineering</strong> from Al Habeeb College of Engineering and Technology in India.
              </p>

              <p>
                My professional experience is centered at the intersection of technical operations and quantitative systems analysis. At <strong className="text-white font-semibold">Euro Live Technologies</strong> in Riga, I served as a Technical Operations Support Representative, where I monitored live digital hardware and software systems 24/7, performed standardized system checks (SOPs), resolved live operational disruptions, and escalated tier-2 technical bugs.
              </p>

              <p>
                Complementing my operations background, my research tenure at <strong className="text-white font-semibold">RTU Management Research</strong> involved formulating quantitative analytical models to evaluate organization management systems across Latvian industry sectors, utilizing engineering tools including <strong className="text-slate-200">AutoCAD</strong>, <strong className="text-slate-200">MS Project</strong>, and <strong className="text-slate-200">Primavera P6</strong>.
              </p>

              <p>
                I actively apply <strong className="text-blue-400 font-medium">Python</strong> and <strong className="text-blue-400 font-medium">SQL</strong> for data querying, logic automation, and process optimization. I view my combined background in engineering methodologies, technical troubleshooting, and programming logic as an asset for resolving complex infrastructure and operational challenges.
              </p>

              {/* Direct CV Summary Quote */}
              <div className="pt-4 border-t border-slate-800 text-xs sm:text-sm text-slate-400 italic">
                "{PERSONAL_INFO.fullSummary}"
              </div>
            </div>

            {/* Core Competencies Quick Summary Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-[#0B1120] border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-semibold text-blue-400">
                  <GraduationCap className="w-4 h-4 text-blue-400" />
                  <span>Engineering Discipline</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  Quantitative modeling, critical path scheduling, and structural system workflows.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0B1120] border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400">
                  <Cpu className="w-4 h-4 text-cyan-400" />
                  <span>Real-Time IT Operations</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  Live digital hardware/software monitoring, SOP checks, and operational shift logging.
                </p>
              </div>
            </div>

          </div>

          {/* Right Column: Focus Areas & Workflows */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* Interactive Pillar Selector */}
            <div className="flex rounded-xl bg-slate-900/90 p-1 border border-slate-800">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
                  activeTab === 'overview'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Pillars
              </button>
              <button
                onClick={() => setActiveTab('it_ops')}
                className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
                  activeTab === 'it_ops'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                IT Operations
              </button>
              <button
                onClick={() => setActiveTab('engineering')}
                className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
                  activeTab === 'engineering'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Engineering
              </button>
              <button
                onClick={() => setActiveTab('tools')}
                className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
                  activeTab === 'tools'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Tools
              </button>
            </div>

            {/* Dynamic Card Content */}
            <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-6 space-y-4 min-h-[380px]">
              
              {activeTab === 'overview' && (
                <div className="space-y-4">
                  <div className="text-sm font-semibold text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-blue-400" />
                    <span>Four Pillars of Professional Practice</span>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 space-y-1">
                      <div className="font-semibold text-slate-200 flex items-center justify-between">
                        <span>1. Quantitative System Modeling</span>
                        <span className="text-[11px] text-blue-400 font-mono">RTU Research</span>
                      </div>
                      <p className="text-slate-400">
                        Mathematical modeling to evaluate organizational performance and reduce systemic latency.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 space-y-1">
                      <div className="font-semibold text-slate-200 flex items-center justify-between">
                        <span>2. Live Hardware & Software Surveillance</span>
                        <span className="text-[11px] text-cyan-400 font-mono">Euro Live Tech</span>
                      </div>
                      <p className="text-slate-400">
                        High-availability monitoring, incident triage, and adherence to strict operational SOPs.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 space-y-1">
                      <div className="font-semibold text-slate-200 flex items-center justify-between">
                        <span>3. Python Scripting & Logic Automation</span>
                        <span className="text-[11px] text-emerald-400 font-mono">Development</span>
                      </div>
                      <p className="text-slate-400">
                        Scripting data extraction, repetitive process automation, and algorithmic problem breakdown.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 space-y-1">
                      <div className="font-semibold text-slate-200 flex items-center justify-between">
                        <span>4. Engineering Scheduling & Documentation</span>
                        <span className="text-[11px] text-purple-400 font-mono">Operations</span>
                      </div>
                      <p className="text-slate-400">
                        MS Project and Primavera P6 scheduling, AutoCAD structural workflows, and technical reporting.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'it_ops' && (
                <div className="space-y-4">
                  <div className="text-sm font-semibold text-white flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-cyan-400" />
                    <span>Real-Time IT Operations Experience</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Demonstrated capability in high-stakes operational environments at Euro Live Technologies in Riga:
                  </p>

                  <ul className="space-y-2.5 text-xs text-slate-300">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>Continuous surveillance of digital hardware and software systems to prevent downtime.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>Execution of structured Standard Operating Procedures (SOPs) for routine verification.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>Maintaining precise operational shift logs for technical review and auditing.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>Systematic bug categorization and escalation to Tier-2 engineering teams.</span>
                    </li>
                  </ul>
                </div>
              )}

              {activeTab === 'engineering' && (
                <div className="space-y-4">
                  <div className="text-sm font-semibold text-white flex items-center gap-2">
                    <Workflow className="w-4 h-4 text-blue-400" />
                    <span>Engineering & Quantitative Mindset</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    How an engineering background drives superior IT problem solving:
                  </p>

                  <div className="space-y-2.5 text-xs text-slate-300">
                    <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                      <span className="font-semibold text-white">Systematic Decomposition:</span> Engineering trains you to isolate variables and identify root causes rather than patching symptoms.
                    </div>
                    <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                      <span className="font-semibold text-white">Quantitative Validation:</span> Every operational efficiency claim is substantiated with concrete data, formulas, and verified benchmarks.
                    </div>
                    <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                      <span className="font-semibold text-white">Process Flow Modeling:</span> Deep comfort with critical paths, dependency trees, and scheduling optimization under constraints.
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'tools' && (
                <div className="space-y-4">
                  <div className="text-sm font-semibold text-white flex items-center gap-2">
                    <FileCheck2 className="w-4 h-4 text-emerald-400" />
                    <span>Tooling & Systems Ecosystem</span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between p-2 rounded bg-slate-900/50 border border-slate-800">
                      <span className="font-medium text-slate-200">Python 3 & Scripting</span>
                      <span className="text-slate-400">VS Code · Logic Flow</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-slate-900/50 border border-slate-800">
                      <span className="font-medium text-slate-200">Relational SQL</span>
                      <span className="text-slate-400">Data Querying & Extraction</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-slate-900/50 border border-slate-800">
                      <span className="font-medium text-slate-200">AutoCAD</span>
                      <span className="text-slate-400">Drafting & Structural Workflows</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-slate-900/50 border border-slate-800">
                      <span className="font-medium text-slate-200">MS Project & Primavera P6</span>
                      <span className="text-slate-400">Process Modeling & Scheduling</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-slate-900/50 border border-slate-800">
                      <span className="font-medium text-slate-200">MS Excel (Advanced)</span>
                      <span className="text-slate-400">Data Analysis & Calculations</span>
                    </div>
                  </div>
                </div>
              )}

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
