import React, { useState } from 'react';
import {
  Code,
  Terminal,
  Cpu,
  Layers,
  FileSpreadsheet,
  Search,
  Check,
} from 'lucide-react';
import { SKILLS } from '../data/portfolioData';
import { SkillItem } from '../types/portfolio';

const CATEGORIES = [
  { id: 'all', label: 'All Skills', icon: Layers },
  { id: 'programming', label: 'Programming & Web', icon: Code },
  { id: 'tools', label: 'Developer Tools', icon: Terminal },
  { id: 'it_support', label: 'IT Support & Operations', icon: Cpu },
  { id: 'engineering', label: 'Engineering & Management', icon: Layers },
  { id: 'productivity', label: 'Productivity & Analysis', icon: FileSpreadsheet },
] as const;

export const Skills: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredSkills = SKILLS.filter((skill) => {
    const matchesCategory =
      selectedCategory === 'all' || skill.category === selectedCategory;
    const matchesSearch =
      skill.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      skill.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getCategoryLabel = (cat: SkillItem['category']) => {
    switch (cat) {
      case 'programming':
        return 'Programming & Web';
      case 'tools':
        return 'Developer Tools';
      case 'it_support':
        return 'IT Support & Ops';
      case 'engineering':
        return 'Engineering & Project';
      case 'productivity':
        return 'Productivity & Data';
    }
  };

  return (
    <section id="skills" className="py-20 lg:py-28 bg-[#080D1A] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl space-y-3">
            <div className="text-xs font-mono text-cyan-400 font-medium">
              Technical Core Competencies
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
              Technical Skills & Tooling
            </h2>
            <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
              Carefully curated from verified experience across software development, live operations, and engineering project environments.
            </p>
          </div>

          {/* Search Bar */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search skills or tools..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-[#0E1626] border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-slate-300"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Category Filter Tabs (Zero-pill button design with clean active states) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-[#0E1626] text-slate-400 hover:text-slate-200 border border-slate-800 hover:border-slate-700'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Skills Cards Grid */}
        {filteredSkills.length === 0 ? (
          <div className="text-center py-12 rounded-2xl bg-[#0B1120] border border-slate-800 p-8 space-y-2">
            <p className="text-sm text-slate-400">No skills found matching "{searchQuery}".</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="text-xs text-blue-400 hover:underline"
            >
              Reset filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSkills.map((skill) => (
              <div
                key={skill.name}
                className="group p-5 rounded-xl bg-[#0B1120] border border-slate-800 hover:border-blue-500/50 hover:bg-[#0D1528] transition-all flex flex-col justify-between"
              >
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="text-sm font-semibold text-white group-hover:text-blue-300 transition-colors">
                      {skill.name}
                    </h3>
                    <span className="text-[11px] font-mono text-slate-500 shrink-0">
                      {getCategoryLabel(skill.category)}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {skill.description}
                  </p>
                </div>

                {skill.highlight && (
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-1.5 text-[11px] text-cyan-400">
                    <Check className="w-3 h-3" />
                    <span>Applied in live operational or thesis research environment</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Verified Notice: No Invented Percentages */}
        <div className="mt-10 p-4 rounded-xl bg-slate-900/50 border border-slate-800 text-xs text-slate-400 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
            <span>
              All competencies correspond strictly to verified CV coursework, thesis modeling, and live operational employment.
            </span>
          </div>
          <span className="font-mono text-[11px] text-slate-500 shrink-0">
            100% Evidence-Grounded
          </span>
        </div>

      </div>
    </section>
  );
};
