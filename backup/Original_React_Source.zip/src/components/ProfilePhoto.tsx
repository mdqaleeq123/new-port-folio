import React from 'react';
import { OFFICIAL_AVATAR } from '../utils/portfolioUtils';

interface ProfilePhotoProps {
  variant?: 'hero' | 'about' | 'nav' | 'compact';
  className?: string;
}

export const ProfilePhoto: React.FC<ProfilePhotoProps> = ({
  variant = 'hero',
  className = '',
}) => {
  if (variant === 'nav') {
    return (
      <div className={`relative w-9 h-9 rounded-xl overflow-hidden border border-blue-500/40 shadow-sm shrink-0 bg-[#0B1120] ${className}`}>
        <img
          src={OFFICIAL_AVATAR}
          alt="Abdul Qaleeq Mohammed"
          className="w-full h-full object-cover object-top"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div className={`relative w-24 h-32 rounded-xl overflow-hidden border border-blue-500/30 shadow-md bg-[#0B1120] ${className}`}>
        <img
          src={OFFICIAL_AVATAR}
          alt="Abdul Qaleeq Mohammed"
          className="w-full h-full object-cover object-top"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  if (variant === 'about') {
    return (
      <div className={`relative w-44 sm:w-52 aspect-[3/4] rounded-2xl overflow-hidden border border-blue-500/30 shadow-xl bg-[#090E1B] shrink-0 ${className}`}>
        <img
          src={OFFICIAL_AVATAR}
          alt="Abdul Qaleeq Mohammed — Profile Portrait"
          className="w-full h-full object-cover object-center"
          referrerPolicy="no-referrer"
        />
        {/* Subtle vignette/border polish */}
        <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10 pointer-events-none" />
      </div>
    );
  }

  // Default: 'hero' — Increased width and height displaying the complete picture
  return (
    <div className={`relative w-56 sm:w-64 md:w-72 aspect-[3/4] rounded-2xl overflow-hidden border-2 border-blue-500/40 shadow-2xl shadow-blue-950/60 bg-[#090E1B] shrink-0 group ${className}`}>
      <img
        src={OFFICIAL_AVATAR}
        alt="Abdul Qaleeq Mohammed — Python Developer & IT Support Engineer"
        className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-[1.02]"
        referrerPolicy="no-referrer"
      />
      {/* Subtle bottom gradient glow for aesthetic depth */}
      <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#080D1A]/60 to-transparent pointer-events-none" />
      <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10 pointer-events-none" />
    </div>
  );
};
