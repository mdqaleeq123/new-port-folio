import React, { useState } from 'react';
import {
  Briefcase,
  MapPin,
  Calendar,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  X,
  Shield,
  Layers,
  Wrench,
} from 'lucide-react';
import { EXPERIENCES } from '../data/portfolioData';
import { ExperienceItem } from '../types/portfolio';

export const Experience: React.FC = () => {
  const [selectedExperience, setSelectedExperience] = useState<ExperienceItem | null>(null);

  return (
    <section id="experience" className="py-20 lg:py-28 bg-[#070B14] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 space-y-3">
          <div className="text-xs font-mono text-blue-400 font-medium">
            Career Timeline & Fieldwork
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
            Professional Experience
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Hands-on technical roles in 24/7 live hardware & software operations and quantitative systems analysis research in Riga, Latvia.
          </p>
        </div>

        {/* Experience Cards / Timeline */}
        <div className="space-y-6">
          {EXPERIENCES.map((exp) => (
            <div
              key={exp.id}
              className="relative p-6 sm:p-8 rounded-2xl bg-[#0B1120] border border-slate-800 hover:border-slate-700 transition-all space-y-6"
            >
              {/* Header Row */}
              <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-mono font-medium text-blue-400">
                      {exp.company}
                    </span>
                    <span className="text-slate-600 text-xs" aria-hidden="true">·</span>
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5" />
                      {exp.location}
                    </span>
                  </div>

                  <h3 className="text-lg sm:text-xl font-bold text-white">
                    {exp.role}
                  </h3>
                </div>

                <div className="flex items-center gap-2 self-start lg:self-auto">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300">
                    <Calendar className="w-3.5 h-3.5 text-blue-400" />
                    <span>{exp.period}</span>
                  </div>

                  <button
                    onClick={() => setSelectedExperience(exp)}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    title="View role deep dive"
                    aria-label={`View full details for ${exp.role}`}
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Summary */}
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {exp.summary}
              </p>

              {/* Responsibilities list directly from CV */}
              <div className="space-y-2.5">
                <div className="text-xs font-semibold text-slate-200">
                  Key Operational Responsibilities:
                </div>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300">
                  {exp.responsibilities.map((resp, i) => (
                    <li key={i} className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-900/50 border border-slate-800/80">
                      <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{resp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Skills and Tools row (Clean unboxed tags) */}
              <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs">
                <div className="flex flex-wrap items-center gap-2 text-slate-400">
                  <span className="text-slate-500 font-medium">Applied Skills:</span>
                  {exp.skillsUsed.map((skill, i) => (
                    <React.Fragment key={skill}>
                      <span className="text-slate-300">{skill}</span>
                      {i < exp.skillsUsed.length - 1 && (
                        <span className="text-slate-700" aria-hidden="true">·</span>
                      )}
                    </React.Fragment>
                  ))}
                </div>

                <button
                  onClick={() => setSelectedExperience(exp)}
                  className="text-xs font-medium text-blue-400 hover:text-blue-300 inline-flex items-center gap-1 transition-colors"
                >
                  <span>Detailed Workflow Breakdown</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Role Details Modal */}
      {selectedExperience && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
        >
          <div
            className="relative w-full max-w-2xl bg-[#0E1626] border border-slate-700 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-6 text-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-mono text-blue-400">
                  {selectedExperience.company} · {selectedExperience.location}
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-white">
                  {selectedExperience.role}
                </h3>
                <div className="text-xs text-slate-400">
                  Tenure: {selectedExperience.period}
                </div>
              </div>

              <button
                onClick={() => setSelectedExperience(null)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                aria-label="Close details"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs sm:text-sm text-slate-300">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-2">
                  <Shield className="w-4 h-4 text-cyan-400" />
                  <span>Standard Operating Procedures & Environment</span>
                </div>
                <p className="text-slate-400 text-xs">
                  {selectedExperience.id === 'euro-live'
                    ? 'Monitored live digital equipment and high-availability broadcast pipelines under strict service uptime agreements. Executed standardized SOP checklists at scheduled intervals to preempt system failure and ensure rapid escalation.'
                    : 'Conducted quantitative data research into organizational efficiency across Latvian commercial and construction sectors, developing analytical models to map workflow dependencies.'}
                </p>
              </div>

              <div className="space-y-2">
                <div className="font-semibold text-white flex items-center gap-2">
                  <Wrench className="w-4 h-4 text-blue-400" />
                  <span>Verified Tools & Systems Used:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedExperience.toolsUsed.map((tool) => (
                    <span
                      key={tool}
                      className="px-2.5 py-1 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-300"
                    >
                      {tool}
                    </span>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <div className="font-semibold text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  <span>Detailed Responsibilities:</span>
                </div>
                <ul className="space-y-2 text-xs text-slate-300">
                  {selectedExperience.responsibilities.map((resp, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-cyan-400 font-mono">0{i + 1}.</span>
                      <span>{resp}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedExperience(null)}
                className="px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors"
              >
                Close Details
              </button>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
