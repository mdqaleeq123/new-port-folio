import React, { useState, useEffect } from 'react';
import {
  X,
  Inbox,
  Trash2,
  Mail,
  Clock,
  CheckCircle2,
  User,
  Lock,
  Unlock,
  KeyRound,
  Send,
  Reply,
  AlertCircle,
  ExternalLink,
  ShieldCheck,
  LogOut,
  Settings,
  Sparkles,
  Edit2,
  Save,
  Code2,
  Download,
} from 'lucide-react';
import {
  getStoredMessages,
  deleteMessage,
  clearStoredMessages,
  RecruiterMessage,
  addMessageReply,
  isAdminAuthenticated,
  loginAdmin,
  logoutAdmin,
  getTargetRecipientEmail,
  setTargetRecipientEmail,
  getGmailComposeUrl,
} from '../utils/portfolioUtils';

interface InboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenCodeModal?: () => void;
}

export const InboxModal: React.FC<InboxModalProps> = ({ isOpen, onClose, onOpenCodeModal }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(isAdminAuthenticated());
  const [messages, setMessages] = useState<RecruiterMessage[]>([]);
  
  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPasscode, setLoginPasscode] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Recipient settings
  const [targetEmail, setTargetEmail] = useState<string>(getTargetRecipientEmail());
  const [isEditingTarget, setIsEditingTarget] = useState<boolean>(false);
  const [customEmailInput, setCustomEmailInput] = useState<string>(getTargetRecipientEmail());

  // Reply state
  const [activeReplyId, setActiveReplyId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState<string>('');
  const [replyToast, setReplyToast] = useState<string | null>(null);

  useEffect(() => {
    const handleAuthChange = () => setIsAuthenticated(isAdminAuthenticated());
    const handleMessagesChange = () => setMessages(getStoredMessages());
    const handleRecipientChange = () => {
      setTargetEmail(getTargetRecipientEmail());
      setCustomEmailInput(getTargetRecipientEmail());
    };

    window.addEventListener('portfolio_auth_changed', handleAuthChange);
    window.addEventListener('portfolio_messages_changed', handleMessagesChange);
    window.addEventListener('portfolio_recipient_changed', handleRecipientChange);

    if (isOpen) {
      setIsAuthenticated(isAdminAuthenticated());
      setMessages(getStoredMessages());
      setTargetEmail(getTargetRecipientEmail());
      setCustomEmailInput(getTargetRecipientEmail());
    }

    return () => {
      window.removeEventListener('portfolio_auth_changed', handleAuthChange);
      window.removeEventListener('portfolio_messages_changed', handleMessagesChange);
      window.removeEventListener('portfolio_recipient_changed', handleRecipientChange);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    const success = loginAdmin(loginEmail, loginPasscode);
    if (success) {
      setIsAuthenticated(true);
      setMessages(getStoredMessages());
    } else {
      setLoginError('Invalid owner credentials. Please check your email and passcode.');
    }
  };

  const handleLogout = () => {
    logoutAdmin();
    setIsAuthenticated(false);
    setActiveReplyId(null);
  };

  const handleSaveTargetEmail = (newEmail: string) => {
    if (!newEmail.includes('@')) {
      alert('Please enter a valid email address.');
      return;
    }
    setTargetRecipientEmail(newEmail);
    setTargetEmail(newEmail);
    setIsEditingTarget(false);
    setReplyToast(`Delivery destination updated to ${newEmail}!`);
    setTimeout(() => setReplyToast(null), 3000);
  };

  const handleDeleteItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Delete this inquiry?')) {
      deleteMessage(id);
      setMessages(getStoredMessages());
    }
  };

  const handleClearAll = () => {
    if (window.confirm('Clear all logged recruiter messages from this browser?')) {
      clearStoredMessages();
      setMessages([]);
    }
  };

  const handleSendReply = (
    msg: RecruiterMessage,
    channel: 'gmail' | 'mailto' | 'log'
  ) => {
    if (!replyText.trim()) return;

    const success = addMessageReply(msg.id, replyText);
    if (success) {
      setReplyToast(`Reply recorded for ${msg.email}`);
      setTimeout(() => setReplyToast(null), 3000);

      const replyContent = `Hi ${msg.name},\n\n${replyText.trim()}\n\nBest regards,\nAbdul Qaleeq Mohammed\nPython Developer & IT Support Engineer\nEmail: ${targetEmail}`;

      if (channel === 'gmail') {
        const gmailUrl = getGmailComposeUrl(msg.email, `Re: ${msg.subject}`, replyContent);
        window.open(gmailUrl, '_blank');
      } else if (channel === 'mailto') {
        const mailSubject = encodeURIComponent(`Re: ${msg.subject}`);
        const mailBody = encodeURIComponent(replyContent);
        window.location.href = `mailto:${msg.email}?subject=${mailSubject}&body=${mailBody}`;
      }

      setReplyText('');
      setActiveReplyId(null);
      setMessages(getStoredMessages());
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div
        className="relative w-full max-w-3xl bg-[#0E1626] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden text-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-800 bg-[#0A101D]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600/10 text-blue-400 border border-blue-500/20">
              {isAuthenticated ? <Unlock className="w-5 h-5 text-emerald-400" /> : <Lock className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-semibold text-white flex items-center gap-2">
                <span>{isAuthenticated ? 'Owner Messages & Reply Console' : 'Owner Inbox Authentication'}</span>
                {isAuthenticated && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800">
                    Admin Active
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">
                {isAuthenticated
                  ? `Logged in as Owner (${targetEmail})`
                  : 'Private portal for Abdul Qaleeq Mohammed'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <>
                {messages.length > 0 && (
                  <button
                    onClick={handleClearAll}
                    className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                    title="Clear all messages"
                    aria-label="Clear all messages"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}

                <button
                  onClick={handleLogout}
                  className="px-2.5 py-1.5 text-xs text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors inline-flex items-center gap-1.5 border border-slate-800"
                  title="Log out of owner portal"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Logout</span>
                </button>
              </>
            )}

            {onOpenCodeModal && (
              <button
                onClick={() => {
                  onClose();
                  onOpenCodeModal();
                }}
                className="px-2.5 py-1.5 text-xs text-cyan-300 hover:text-white bg-cyan-950/40 hover:bg-cyan-900/60 rounded-lg border border-cyan-800/60 transition-colors inline-flex items-center gap-1.5"
                title="Download Project Source Code (.ZIP) & PC Setup Guide"
              >
                <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Get Code</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors ml-1"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {!isAuthenticated ? (
            /* Login Form */
            <div className="max-w-md mx-auto py-6 space-y-6">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-2xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mx-auto">
                  <KeyRound className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-bold text-white">Owner Security Verification</h4>
                <p className="text-xs text-slate-400">
                  To protect recruiter privacy, messages and reply tools are restricted to Abdul Qaleeq Mohammed.
                </p>
              </div>

              {loginError && (
                <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800/60 text-xs text-rose-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">
                    Owner Email
                  </label>
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="e.g. name@example.com"
                    className="w-full px-3.5 py-2.5 bg-[#070B14] border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">
                    Passcode / Password
                  </label>
                  <input
                    type="password"
                    value={loginPasscode}
                    onChange={(e) => setLoginPasscode(e.target.value)}
                    placeholder="Enter owner passcode"
                    className="w-full px-3.5 py-2.5 bg-[#070B14] border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg text-xs shadow-sm transition-colors"
                >
                  Log In to View Messages & Reply
                </button>
              </form>

              {/* Secure Notice */}
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-3 text-xs text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Protected Owner Area: Access is restricted to portfolio administrators.</span>
              </div>
            </div>
          ) : (
            /* Authenticated Inbox & Reply Stream */
            <div className="space-y-5">
              {/* Target Delivery Email Settings Banner */}
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Settings className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span className="font-semibold text-white">Delivery Destination Email:</span>
                    <span className="font-mono text-cyan-300 font-medium">{targetEmail}</span>
                  </div>

                  <button
                    onClick={() => setIsEditingTarget(!isEditingTarget)}
                    className="text-blue-400 hover:text-blue-300 underline font-medium text-[11px] self-start sm:self-auto"
                  >
                    {isEditingTarget ? 'Close' : 'Change Destination Email'}
                  </button>
                </div>

                {isEditingTarget && (
                  <div className="pt-2 border-t border-slate-800/80 space-y-2">
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                      <input
                        type="email"
                        value={customEmailInput}
                        onChange={(e) => setCustomEmailInput(e.target.value)}
                        placeholder="e.g. noshabakhanwebdev1@gmail.com"
                        className="px-3 py-1.5 bg-[#070B14] border border-slate-700 rounded-lg text-xs text-white flex-1 focus:outline-none focus:border-blue-500"
                      />
                      <button
                        onClick={() => handleSaveTargetEmail(customEmailInput)}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold inline-flex items-center justify-center gap-1"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>Save</span>
                      </button>
                    </div>

                    <div className="text-[11px] text-slate-400">
                      <span>Enter the email address where all portfolio messages should be forwarded.</span>
                    </div>
                  </div>
                )}

                <div className="p-2.5 rounded-lg bg-blue-950/30 border border-blue-900/40 text-[11px] text-slate-300 leading-relaxed">
                  <strong className="text-blue-300">Note on FormSubmit Activation:</strong> The very first time a message is sent to a new email address, FormSubmit delivers an email with a 1-click <em>"Activate Form"</em> link. Once activated in your inbox, all incoming contact inquiries will automatically arrive directly in your inbox.
                </div>
              </div>

              {replyToast && (
                <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{replyToast}</span>
                </div>
              )}

              {/* Message List */}
              {messages.length === 0 ? (
                <div className="text-center py-12 space-y-2">
                  <Mail className="w-10 h-10 text-slate-600 mx-auto" />
                  <p className="text-sm text-slate-300 font-medium">No messages currently in inbox</p>
                  <p className="text-xs text-slate-500">
                    When visitors or recruiters submit the contact form, inquiries will appear here for you to reply.
                  </p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isReplying = activeReplyId === msg.id;
                  const hasReplies = msg.replies && msg.replies.length > 0;

                  return (
                    <div
                      key={msg.id}
                      className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800 hover:border-slate-700/80 transition-all space-y-4"
                    >
                      {/* Message Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2 text-xs">
                            <User className="w-4 h-4 text-blue-400" />
                            <span className="font-bold text-white text-sm">{msg.name}</span>
                            <span className="text-slate-400 font-mono text-[11px]">
                              &lt;{msg.email}&gt;
                            </span>
                          </div>
                          <div className="text-xs font-semibold text-cyan-300 pt-1">
                            Subject: {msg.subject}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-start sm:self-auto">
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-mono">
                            <Clock className="w-3 h-3 text-slate-500" />
                            <span>{msg.timestamp}</span>
                          </div>

                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                              hasReplies
                                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                                : 'bg-cyan-950/60 text-cyan-300 border-cyan-800'
                            }`}
                          >
                            {hasReplies ? 'Replied' : 'New Inquiry'}
                          </span>

                          <button
                            onClick={(e) => handleDeleteItem(msg.id, e)}
                            className="p-1 text-slate-500 hover:text-rose-400 rounded transition-colors"
                            title="Delete inquiry"
                            aria-label="Delete inquiry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Original Message Body */}
                      <div className="p-3.5 rounded-xl bg-[#070B14] border border-slate-800/80 text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">
                        {msg.message}
                      </div>

                      {/* Previous Replies Thread */}
                      {hasReplies && (
                        <div className="pl-4 border-l-2 border-blue-500/40 space-y-2 pt-1">
                          <div className="text-[11px] font-semibold text-blue-400 flex items-center gap-1.5">
                            <Reply className="w-3.5 h-3.5" />
                            <span>Sent Replies ({msg.replies?.length}):</span>
                          </div>
                          {msg.replies?.map((rep) => (
                            <div
                              key={rep.id}
                              className="p-3 rounded-lg bg-blue-950/20 border border-blue-900/40 text-xs space-y-1"
                            >
                              <div className="flex items-center justify-between text-[10px] text-slate-400">
                                <span>From: {rep.senderEmail} → {rep.recipientEmail}</span>
                                <span className="font-mono">{rep.sentAt}</span>
                              </div>
                              <p className="text-slate-200 whitespace-pre-wrap">{rep.replyText}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Reply Actions & Form */}
                      <div className="pt-2">
                        {isReplying ? (
                          /* Active Reply Editor */
                          <div className="p-4 rounded-xl bg-slate-900/90 border border-blue-600/40 space-y-3">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-semibold text-white flex items-center gap-1.5">
                                <Reply className="w-3.5 h-3.5 text-blue-400" />
                                <span>Compose Reply to {msg.name} ({msg.email})</span>
                              </span>
                              <button
                                onClick={() => setActiveReplyId(null)}
                                className="text-slate-400 hover:text-white"
                              >
                                Cancel
                              </button>
                            </div>

                            <textarea
                              rows={4}
                              value={replyText}
                              onChange={(e) => setReplyText(e.target.value)}
                              placeholder={`Write your reply to ${msg.name}...`}
                              className="w-full px-3 py-2 bg-[#070B14] border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500 resize-none"
                            />

                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                              <div className="text-[11px] text-slate-400">
                                Replying to: <span className="text-white font-mono">{msg.email}</span>
                              </div>

                              <div className="flex flex-wrap items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => handleSendReply(msg, 'log')}
                                  disabled={!replyText.trim()}
                                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors"
                                >
                                  Save to Log
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleSendReply(msg, 'gmail')}
                                  disabled={!replyText.trim()}
                                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors inline-flex items-center gap-1.5"
                                >
                                  <Mail className="w-3.5 h-3.5" />
                                  <span>Send via Gmail Web</span>
                                  <ExternalLink className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          </div>
                        ) : (
                          /* Collapsed Reply Trigger */
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <button
                              onClick={() => {
                                setActiveReplyId(msg.id);
                                setReplyText(
                                  `Hi ${msg.name},\n\nThank you for reaching out regarding "${msg.subject}". `
                                );
                              }}
                              className="px-3.5 py-1.5 text-xs font-semibold bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 hover:text-blue-300 rounded-lg border border-blue-500/30 transition-colors inline-flex items-center gap-1.5"
                            >
                              <Reply className="w-3.5 h-3.5" />
                              <span>Reply to {msg.email}</span>
                            </button>

                            <div className="flex items-center gap-3 text-[11px]">
                              <a
                                href={getGmailComposeUrl(
                                  msg.email,
                                  `Re: ${msg.subject}`,
                                  `Hi ${msg.name},\n\nThank you for reaching out!`
                                )}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-400 hover:underline inline-flex items-center gap-1"
                              >
                                <span>Open in Gmail</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>

                              <span className="text-slate-700" aria-hidden="true">·</span>

                              <a
                                href={`mailto:${msg.email}?subject=Re: ${encodeURIComponent(msg.subject)}`}
                                className="text-slate-400 hover:text-white underline inline-flex items-center gap-1"
                              >
                                <span>Mailto</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>

        {/* Footer Bar */}
        <div className="px-6 py-3 border-t border-slate-800 bg-[#0A101D] flex justify-between items-center text-xs text-slate-400">
          <div>
            {isAuthenticated ? (
              <span>{messages.length} message(s) stored locally</span>
            ) : (
              <span>Secure Owner Portal</span>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
