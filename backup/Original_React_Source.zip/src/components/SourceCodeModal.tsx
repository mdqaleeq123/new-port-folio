import React, { useState } from 'react';
import { X, Download, Terminal, Check, Copy, Laptop, FolderArchive, ArrowRight, ExternalLink, HelpCircle } from 'lucide-react';

interface SourceCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SourceCodeModal: React.FC<SourceCodeModalProps> = ({ isOpen, onClose }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleDownloadZip = () => {
    setIsDownloading(true);
    const link = document.createElement('a');
    link.href = '/assets/aistudio/abdul-qaleeq-portfolio-source.zip';
    link.download = 'abdul-qaleeq-portfolio-source.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => setIsDownloading(false), 1500);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-labelledby="source-code-modal-title"
    >
      <div className="relative w-full max-w-3xl max-h-[92vh] flex flex-col bg-[#0B1120] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#080D1A]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <h2 id="source-code-modal-title" className="text-lg font-bold text-white flex items-center gap-2">
                Download Code & PC Installation Guide
              </h2>
              <p className="text-xs text-slate-400">
                Complete React + Vite + Tailwind source code for Abdul Qaleeq's portfolio
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-lg transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-300">
          
          {/* Main Action Banner */}
          <div className="bg-gradient-to-r from-blue-950/60 to-slate-900/90 border border-blue-500/30 rounded-xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                Ready Package · 1.8 MB
              </span>
              <h3 className="text-base font-semibold text-white">
                abdul-qaleeq-portfolio-source.zip
              </h3>
              <p className="text-xs text-slate-400 max-w-md">
                Contains all components, portfolio data, assets (real portrait & CV PDF), Tailwind styling, and configurations.
              </p>
            </div>
            <button
              onClick={handleDownloadZip}
              disabled={isDownloading}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-medium shadow-lg shadow-blue-600/30 hover:shadow-blue-500/40 transition-all flex items-center justify-center gap-2 text-sm shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>{isDownloading ? 'Downloading...' : 'Download ZIP File'}</span>
            </button>
          </div>

          {/* Quick Pre-requisite Notice */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex items-start gap-3">
            <Laptop className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <p className="font-semibold text-slate-200">System Requirement: Node.js (Windows, Mac, or Linux)</p>
              <p className="text-slate-400">
                You only need <strong>Node.js (LTS version)</strong> installed on your PC to run this project. If you don't have it yet:
              </p>
              <a
                href="https://nodejs.org/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-medium underline mt-1"
              >
                <span>Download free from nodejs.org</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Step-by-Step Instructions */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider text-slate-400">
              How to Install & Run on Your PC
            </h4>

            {/* Step 1 */}
            <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2 font-semibold text-slate-100">
                <span className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 border border-blue-500/40 flex items-center justify-center text-xs">
                  1
                </span>
                <span>Extract the downloaded ZIP file</span>
              </div>
              <p className="text-xs text-slate-400 pl-8">
                Right-click <code className="text-slate-300 bg-slate-800 px-1 py-0.5 rounded">abdul-qaleeq-portfolio-source.zip</code> in your Downloads folder and choose <strong>"Extract All..."</strong> to a folder (e.g. into your Documents or Desktop).
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2 font-semibold text-slate-100">
                <span className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 border border-blue-500/40 flex items-center justify-center text-xs">
                  2
                </span>
                <span>Open Terminal in that project folder</span>
              </div>
              <p className="text-xs text-slate-400 pl-8">
                In Windows File Explorer, open the extracted project folder. Click in the top address bar, type <code className="text-slate-300 bg-slate-800 px-1 py-0.5 rounded">cmd</code> or <code className="text-slate-300 bg-slate-800 px-1 py-0.5 rounded">powershell</code>, and press <strong>Enter</strong>.
                <br />
                <em>(Or in VS Code: click <strong>File &gt; Open Folder</strong>, then press <kbd className="bg-slate-800 px-1.5 py-0.5 rounded text-[11px] text-slate-300">Ctrl + ~</kbd> to open the integrated terminal).</em>
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-semibold text-slate-100">
                  <span className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 border border-blue-500/40 flex items-center justify-center text-xs">
                    3
                  </span>
                  <span>Install packages</span>
                </div>
                <button
                  onClick={() => copyToClipboard('npm install', 1)}
                  className="px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 flex items-center gap-1 transition-colors"
                >
                  {copiedIndex === 1 ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedIndex === 1 ? 'Copied' : 'Copy command'}</span>
                </button>
              </div>
              <div className="pl-8 space-y-2">
                <div className="bg-black/60 font-mono text-xs text-cyan-300 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between">
                  <span>npm install</span>
                </div>
                <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <span>If Windows npm shows an ERESOLVE peer error, run:</span>
                  <button
                    onClick={() => copyToClipboard('npm install --legacy-peer-deps', 99)}
                    className="font-mono text-cyan-300 bg-slate-900 px-2 py-1 rounded border border-amber-500/30 flex items-center gap-1 hover:bg-slate-800 transition-colors self-start sm:self-auto"
                  >
                    <span>npm install --legacy-peer-deps</span>
                    {copiedIndex === 99 ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
                <p className="text-xs text-slate-400">
                  Downloads React 19, Tailwind CSS v4, Lucide icons, and Motion into your local <code className="text-slate-300">node_modules</code>.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-semibold text-slate-100">
                  <span className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 border border-blue-500/40 flex items-center justify-center text-xs">
                    4
                  </span>
                  <span>Run the development server</span>
                </div>
                <button
                  onClick={() => copyToClipboard('npm run dev', 2)}
                  className="px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 flex items-center gap-1 transition-colors"
                >
                  {copiedIndex === 2 ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedIndex === 2 ? 'Copied' : 'Copy command'}</span>
                </button>
              </div>
              <div className="pl-8">
                <div className="bg-black/60 font-mono text-xs text-green-400 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between">
                  <span>npm run dev</span>
                </div>
                <p className="text-xs text-slate-400 mt-1.5">
                  Starts your local server instantly. Open your browser at <code className="text-blue-300 bg-slate-800 px-1 py-0.5 rounded">http://localhost:5173</code> to view your portfolio!
                </p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-semibold text-slate-100">
                  <span className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 border border-blue-500/40 flex items-center justify-center text-xs">
                    5
                  </span>
                  <span>Build for free Web Hosting (Optional)</span>
                </div>
                <button
                  onClick={() => copyToClipboard('npm run build', 3)}
                  className="px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 flex items-center gap-1 transition-colors"
                >
                  {copiedIndex === 3 ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedIndex === 3 ? 'Copied' : 'Copy command'}</span>
                </button>
              </div>
              <div className="pl-8">
                <div className="bg-black/60 font-mono text-xs text-yellow-300 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between">
                  <span>npm run build</span>
                </div>
                <p className="text-xs text-slate-400 mt-1.5">
                  Generates an optimized static <code className="text-slate-300">dist/</code> directory. You can upload this directly to <strong>Vercel</strong>, <strong>Netlify</strong>, or <strong>GitHub Pages</strong> for free 24/7 online hosting.
                </p>
              </div>
            </div>

          </div>

          {/* Quick FAQ */}
          <div className="border-t border-slate-800 pt-4 text-xs text-slate-400 space-y-2">
            <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
              <HelpCircle className="w-4 h-4 text-blue-400" />
              <span>Where do I edit my portfolio information?</span>
            </div>
            <p>
              Open <code className="text-slate-300 bg-slate-800 px-1 py-0.5 rounded">src/data/portfolioData.ts</code> in VS Code or any text editor. You can update your phone, email, bio, project list, and skills with no database required.
            </p>
          </div>

        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-[#080D1A]">
          <span className="text-xs text-slate-500">
            Included: <code className="text-slate-400">README.md</code> in ZIP root
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download ZIP (1.8 MB)</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
