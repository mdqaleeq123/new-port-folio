import React, { useState, useEffect } from 'react';
import { Menu, X, Download, FileText, Mail, Lock, Code2 } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { downloadResumePdf, getStoredMessages } from '../utils/portfolioUtils';
import { ProfilePhoto } from './ProfilePhoto';

interface NavbarProps {
  onOpenResumeModal: () => void;
  onOpenInboxModal: () => void;
  onOpenCodeModal?: () => void;
}

const NAV_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Experience', href: '#experience' },
  { label: 'Projects', href: '#projects' },
  { label: 'Education', href: '#education' },
  { label: 'Contact', href: '#contact' },
];

export const Navbar: React.FC<NavbarProps> = ({ onOpenResumeModal, onOpenInboxModal, onOpenCodeModal }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [messageCount, setMessageCount] = useState<number>(0);
  const [isDownloading, setIsDownloading] = useState(false);

  useEffect(() => {
    const handleMessagesChange = () => setMessageCount(getStoredMessages().length);
    setMessageCount(getStoredMessages().length);

    window.addEventListener('portfolio_messages_changed', handleMessagesChange);

    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      const sections = NAV_LINKS.map((link) => link.href.substring(1));
      const scrollPosition = window.scrollY + 120;

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = document.getElementById(sections[i]);
        if (section && section.offsetTop <= scrollPosition) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('portfolio_messages_changed', handleMessagesChange);
    };
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.substring(1);
    const targetElement = document.getElementById(targetId);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(targetId);
      setMobileMenuOpen(false);
    }
  };

  const handleDownloadCV = async () => {
    setIsDownloading(true);
    await downloadResumePdf();
    setIsDownloading(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'bg-[#080D1A]/95 backdrop-blur-md border-b border-slate-800/80 shadow-lg shadow-black/20'
          : 'bg-transparent border-b border-slate-800/30'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-18">
          
          {/* Zone 1: Single text element wordmark with User's Photo */}
          <a
            href="#home"
            onClick={(e) => handleNavClick(e, '#home')}
            className="group flex items-center gap-3 whitespace-nowrap shrink-0 text-white font-bold text-base tracking-tight hover:text-blue-400 transition-colors"
          >
            <ProfilePhoto variant="nav" />
            <span className="font-semibold text-slate-100 group-hover:text-white">
              Abdul Qaleeq Mohammed
            </span>
          </a>

          {/* Zone 2: Navigation Links */}
          <nav
            aria-label="Main Navigation"
            className="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-medium text-slate-400"
          >
            {NAV_LINKS.map((link) => {
              const isActive = activeSection === link.href.substring(1);
              return (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={`whitespace-nowrap shrink-0 transition-colors py-1 relative ${
                    isActive
                      ? 'text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500 rounded-full"
                      aria-hidden="true"
                    />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Zone 3: Primary Actions (Preview CV, Download CV, Get Code, and Discreet Owner Portal) */}
          <div className="hidden sm:flex items-center gap-2.5 shrink-0">
            {onOpenCodeModal && (
              <button
                onClick={onOpenCodeModal}
                className="px-3 py-1.5 text-xs font-medium text-cyan-300 hover:text-white bg-cyan-950/40 hover:bg-cyan-900/60 rounded-lg border border-cyan-800/50 transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
                title="Download Source Code (.ZIP) & PC Installation Guide"
              >
                <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Get Code</span>
              </button>
            )}

            <button
              onClick={onOpenInboxModal}
              className="p-2 text-slate-400 hover:text-cyan-300 hover:bg-slate-800/80 rounded-lg border border-slate-800 transition-colors"
              title="Owner Portal (Private Messages & Replies)"
              aria-label="Owner Portal"
            >
              <Lock className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={onOpenResumeModal}
              className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 rounded-lg border border-slate-700/60 transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
              title="Preview CV Document"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>Preview CV</span>
            </button>

            <button
              onClick={handleDownloadCV}
              disabled={isDownloading}
              className="px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg shadow-sm hover:shadow-blue-600/25 transition-all whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isDownloading ? 'Downloading...' : 'Download CV'}</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={handleDownloadCV}
              className="p-2 text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors"
              aria-label="Download CV"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              aria-label={mobileMenuOpen ? 'Close Navigation Menu' : 'Open Navigation Menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-800 bg-[#0A101E]/95 backdrop-blur-xl px-4 pt-3 pb-6 space-y-3">
          <nav className="flex flex-col space-y-1">
            {NAV_LINKS.map((link) => {
              const isActive = activeSection === link.href.substring(1);
              return (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                    isActive
                      ? 'bg-blue-600/20 text-blue-400 font-semibold'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  {link.label}
                </a>
              );
            })}
          </nav>

          <div className="pt-3 border-t border-slate-800/80 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenInboxModal();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-slate-400 hover:text-white bg-slate-900/60 rounded-lg border border-slate-800 transition-colors"
            >
              <Lock className="w-3.5 h-3.5 text-cyan-400" />
              <span>Owner Portal & Messages</span>
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenResumeModal();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
            >
              <FileText className="w-4 h-4 text-blue-400" />
              <span>Preview Full Resume</span>
            </button>

            {onOpenCodeModal && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenCodeModal();
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium text-cyan-300 bg-cyan-950/50 hover:bg-cyan-900/60 rounded-lg border border-cyan-800/60 transition-colors"
              >
                <Code2 className="w-4 h-4 text-cyan-400" />
                <span>Download Code & PC Setup Guide</span>
              </button>
            )}

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                handleDownloadCV();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download CV (PDF)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
