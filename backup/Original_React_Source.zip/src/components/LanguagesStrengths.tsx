import React from 'react';
import {
  Globe,
  Brain,
  MessageSquare,
  Compass,
  CalendarDays,
  CheckCircle,
} from 'lucide-react';
import { LANGUAGES, STRENGTHS } from '../data/portfolioData';

export const LanguagesStrengths: React.FC = () => {
  const getStrengthIcon = (index: number) => {
    switch (index) {
      case 0:
        return Brain;
      case 1:
        return Compass;
      case 2:
        return CheckCircle;
      case 3:
        return MessageSquare;
      case 4:
        return CalendarDays;
      default:
        return Brain;
    }
  };

  return (
    <section id="strengths" className="py-20 lg:py-28 bg-[#080D1A] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Languages (CV Verified) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="space-y-2">
              <div className="text-xs font-mono text-cyan-400 font-medium">
                Multilingual Competence
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                Languages
              </h2>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                Proficiency levels strictly verified according to international CEFR frameworks.
              </p>
            </div>

            <div className="space-y-4">
              {LANGUAGES.map((lang) => (
                <div
                  key={lang.language}
                  className="p-5 rounded-xl bg-[#0B1120] border border-slate-800 space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <Globe className="w-4 h-4 text-blue-400" />
                      <span className="font-semibold text-white text-sm">
                        {lang.language}
                      </span>
                    </div>

                    <div className="text-xs font-mono text-cyan-400 font-semibold">
                      {lang.levelCode}
                    </div>
                  </div>

                  <div className="text-xs text-slate-300 font-medium">
                    {lang.proficiency}
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {lang.notes}
                  </p>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 text-xs text-slate-400">
              <strong className="text-slate-300">English Medium Education:</strong> Completed 2-year Master of Science curriculum, coursework, and technical thesis defense in English in Riga, Latvia.
            </div>
          </div>

          {/* Right Column: Professional Strengths */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-2">
              <div className="text-xs font-mono text-blue-400 font-medium">
                Core Strengths & Mindset
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                Professional Strengths
              </h2>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                Foundational attributes cultivated across engineering design, project scheduling, and live technical system operations.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {STRENGTHS.map((str, index) => {
                const Icon = getStrengthIcon(index);
                return (
                  <div
                    key={str.title}
                    className={`p-5 rounded-xl bg-[#0B1120] border border-slate-800 hover:border-slate-700 transition-all space-y-2 ${
                      index === 4 ? 'sm:col-span-2' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2.5 text-blue-400">
                      <div className="p-2 rounded-lg bg-blue-600/10 border border-blue-500/20 text-blue-400">
                        <Icon className="w-4 h-4" />
                      </div>
                      <h3 className="font-semibold text-white text-sm">
                        {str.title}
                      </h3>
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed">
                      {str.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
