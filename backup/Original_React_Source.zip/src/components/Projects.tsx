import React, { useState } from 'react';
import {
  GraduationCap,
  Layers,
  ChevronRight,
  Code2,
  Cpu,
  Database,
  ExternalLink,
  Plus,
  X,
  Copy,
  Check,
  Activity,
  Workflow,
  Sparkles,
  Info,
} from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { ProjectItem } from '../types/portfolio';

export const Projects: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [showAddProjectModal, setShowAddProjectModal] = useState(false);
  const [copiedTemplate, setCopiedTemplate] = useState(false);

  // Template state for new project builder
  const [newTitle, setNewTitle] = useState('Automated Production Incident Triage');
  const [newTech, setNewTech] = useState('Python, SQLite, Regex, SMTP Alerting');
  const [newDesc, setNewDesc] = useState('Automated Python script parsing system logs to detect recurring error spikes and notify Tier-2 teams.');

  const featuredProject = PROJECTS.find((p) => p.isFeatured) || PROJECTS[0];
  const templateProjects = PROJECTS.filter((p) => !p.isFeatured);

  const handleCopyTemplateJson = () => {
    const templateData = {
      title: newTitle,
      technologies: newTech.split(',').map((s) => s.trim()),
      description: newDesc,
      status: 'Ready to link GitHub repo',
    };
    navigator.clipboard.writeText(JSON.stringify(templateData, null, 2));
    setCopiedTemplate(true);
    setTimeout(() => setCopiedTemplate(false), 2000);
  };

  return (
    <section id="projects" className="py-20 lg:py-28 bg-[#080D1A] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div className="max-w-2xl space-y-3">
            <div className="text-xs font-mono text-cyan-400 font-medium">
              Featured Research & Implementations
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
              Featured Projects & Systems
            </h2>
            <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
              Academic research defended with 1st Class Honours at Riga Technical University alongside extensible project slots for upcoming Python automation and IT tooling.
            </p>
          </div>

          <button
            onClick={() => setShowAddProjectModal(true)}
            className="px-4 py-2.5 text-xs font-semibold bg-slate-800/90 hover:bg-slate-800 text-slate-200 hover:text-white rounded-lg border border-slate-700 transition-all inline-flex items-center gap-2 self-start md:self-auto shrink-0"
          >
            <Plus className="w-4 h-4 text-blue-400" />
            <span>Add / Template New Project</span>
          </button>
        </div>

        {/* 1. Primary Featured Project Card (Master's Thesis) */}
        <div className="p-6 sm:p-8 lg:p-10 rounded-2xl bg-[#0B1120] border border-blue-900/50 shadow-xl space-y-8 relative overflow-hidden">
          {/* Subtle tech background highlight */}
          <div
            className="absolute top-0 right-0 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none"
            aria-hidden="true"
          />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
            
            {/* Left Col: Project Synopsis & Objectives */}
            <div className="lg:col-span-7 space-y-5">
              
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-blue-400">
                  <span className="flex items-center gap-1 font-semibold">
                    <GraduationCap className="w-4 h-4" />
                    {featuredProject.institution}
                  </span>
                  <span className="text-slate-600" aria-hidden="true">·</span>
                  <span className="text-slate-400">{featuredProject.subtitle}</span>
                  <span className="text-slate-600" aria-hidden="true">·</span>
                  <span className="text-emerald-400 font-semibold">1st Class Honours</span>
                </div>

                <h3 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
                  {featuredProject.title}
                </h3>
              </div>

              {/* Exact Description from CV */}
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
                "{featuredProject.description}"
              </p>

              {/* Problem & Objective Box */}
              <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
                <div className="text-xs font-semibold text-slate-200 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span>Problem Statement & Core Objective</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {featuredProject.problem}
                </p>
              </div>

              {/* Technologies & Skills tags (Clean unboxed tags) */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300">
                  Technologies & Core Methodologies:
                </div>
                <div className="flex flex-wrap gap-2 text-xs">
                  {featuredProject.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-2.5 py-1 rounded bg-[#070B14] border border-slate-800 text-slate-300 font-mono text-[11px]"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  onClick={() => setSelectedProject(featuredProject)}
                  className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white rounded-lg shadow-sm transition-all inline-flex items-center gap-2"
                >
                  <span>Explore Full Methodology</span>
                  <ChevronRight className="w-4 h-4" />
                </button>

                <div className="text-xs text-slate-500 italic">
                  *Defended at RTU Faculty of Civil Engineering
                </div>
              </div>

            </div>

            {/* Right Col: Technical Process Modeling Diagram (Custom Abstract Visualization) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="p-5 rounded-xl bg-[#070B14] border border-slate-800 space-y-4">
                <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-3">
                  <span className="font-mono text-cyan-400 font-medium">
                    Optimization Model Flowchart
                  </span>
                  <span className="text-[11px] font-mono text-slate-500">
                    RTU-Thesis-Arch
                  </span>
                </div>

                {/* Step-by-step technical pipeline */}
                <div className="space-y-3 text-xs">
                  <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800/80 space-y-1">
                    <div className="flex items-center justify-between text-slate-200 font-medium">
                      <span>01. Operational Parameter Ingestion</span>
                      <span className="text-[10px] font-mono text-slate-500">Input Phase</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Standardize process times, handoff milestones, and technical resources across sector workflows.
                    </p>
                  </div>

                  <div className="flex justify-center -my-1 text-slate-600">
                    ↓
                  </div>

                  <div className="p-3 rounded-lg bg-blue-950/30 border border-blue-900/60 space-y-1">
                    <div className="flex items-center justify-between text-blue-300 font-medium">
                      <span>02. Python Quantitative Modeling</span>
                      <span className="text-[10px] font-mono text-blue-400">Analytical Core</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Scripted algorithmic routines calculate dependency bottlenecks and simulate schedule compression.
                    </p>
                  </div>

                  <div className="flex justify-center -my-1 text-slate-600">
                    ↓
                  </div>

                  <div className="p-3 rounded-lg bg-emerald-950/20 border border-emerald-900/50 space-y-1">
                    <div className="flex items-center justify-between text-emerald-300 font-medium">
                      <span>03. Streamlined Operational Framework</span>
                      <span className="text-[10px] font-mono text-emerald-400">Output Result</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Validated management model delivering measurable efficiency gains for technical coordination.
                    </p>
                  </div>
                </div>

                <div className="pt-2 text-[11px] text-slate-500 text-center font-mono">
                  Theoretical and empirical validation completed at RTU
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* 2. Extensible Project Showcase / Template Slots */}
        <div className="mt-12 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white">
              Upcoming & Extensible Project Slots
            </h3>
            <span className="text-xs text-slate-400">
              Configurable templates for Python scripts, automation & data queries
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {templateProjects.map((project) => (
              <div
                key={project.id}
                className="p-6 rounded-2xl bg-[#0B1120] border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono text-cyan-400">
                      {project.status}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {project.subtitle}
                    </span>
                  </div>

                  <h4 className="text-base font-bold text-white">
                    {project.title}
                  </h4>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {project.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 space-y-3">
                  <div className="flex flex-wrap gap-1.5 text-xs">
                    {project.technologies.map((t) => (
                      <span
                        key={t}
                        className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 text-[11px] font-mono"
                      >
                        {t}
                      </span>
                    ))}
                  </div>

                  <button
                    onClick={() => setSelectedProject(project)}
                    className="text-xs font-medium text-blue-400 hover:text-blue-300 inline-flex items-center gap-1"
                  >
                    <span>View Architectural Specification</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Project Details Modal */}
      {selectedProject && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
        >
          <div
            className="relative w-full max-w-3xl max-h-[90vh] bg-[#0E1626] border border-slate-700 rounded-2xl shadow-2xl p-6 sm:p-8 overflow-y-auto space-y-6 text-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-mono text-blue-400">
                  {selectedProject.institution} · {selectedProject.subtitle}
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-white">
                  {selectedProject.title}
                </h3>
              </div>

              <button
                onClick={() => setSelectedProject(null)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                aria-label="Close project modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs sm:text-sm text-slate-300">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="font-semibold text-white">Project Overview:</div>
                <p className="text-slate-400 text-xs leading-relaxed">
                  {selectedProject.description}
                </p>
              </div>

              <div className="space-y-2">
                <div className="font-semibold text-white">Problem & Objective:</div>
                <p className="text-slate-400 text-xs leading-relaxed">
                  {selectedProject.problem}
                </p>
              </div>

              <div className="space-y-2">
                <div className="font-semibold text-white">Methodology & Framework:</div>
                <ul className="space-y-2 text-xs text-slate-300">
                  {selectedProject.methodology.map((m, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-blue-400 font-mono font-bold">•</span>
                      <span>{m}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-2">
                <div className="font-semibold text-white">Technologies & Tools:</div>
                <div className="flex flex-wrap gap-2">
                  {selectedProject.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-2.5 py-1 text-xs bg-slate-900 border border-slate-800 rounded-lg text-cyan-300 font-mono"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {selectedProject.highlights.length > 0 && (
                <div className="space-y-2">
                  <div className="font-semibold text-white">Key Highlights:</div>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {selectedProject.highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-between items-center">
              <div className="text-xs text-slate-500 font-mono">
                Status: {selectedProject.status}
              </div>
              <button
                onClick={() => setSelectedProject(null)}
                className="px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors"
              >
                Close View
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Template Project Modal */}
      {showAddProjectModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
        >
          <div
            className="relative w-full max-w-xl bg-[#0E1626] border border-slate-700 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-6 text-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-mono text-cyan-400">
                  Extensibility Tool
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-white">
                  Add / Template New Project
                </h3>
                <p className="text-xs text-slate-400">
                  Define an additional Python script, automation tool, or IT support project structure.
                </p>
              </div>

              <button
                onClick={() => setShowAddProjectModal(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium">Project Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium">Technologies (comma-separated)</label>
                <input
                  type="text"
                  value={newTech}
                  onChange={(e) => setNewTech(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium">Brief Description</label>
                <textarea
                  rows={3}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>

              <div className="p-3 rounded-lg bg-blue-950/30 border border-blue-900/40 text-[11px] text-blue-300 flex items-start gap-2">
                <Info className="w-4 h-4 shrink-0 text-blue-400 mt-0.5" />
                <span>
                  Copy this structured JSON snippet into <code className="font-mono text-cyan-300">src/data/portfolioData.ts</code> or export for your GitHub portfolio repository.
                </span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                onClick={handleCopyTemplateJson}
                className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white rounded-lg shadow-sm transition-all inline-flex items-center gap-1.5"
              >
                {copiedTemplate ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedTemplate ? 'Copied JSON!' : 'Copy Template JSON'}</span>
              </button>

              <button
                onClick={() => setShowAddProjectModal(false)}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
