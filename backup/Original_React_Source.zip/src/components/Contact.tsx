import React, { useState, useEffect } from 'react';
import {
  Mail,
  Phone,
  MapPin,
  Send,
  MessageSquare,
  Copy,
  Check,
  ExternalLink,
  Clock,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Inbox,
  Sparkles,
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import {
  saveRecruiterMessage,
  RecruiterMessage,
  sendEmailViaFormSubmit,
  EmailSendResult,
  getTargetRecipientEmail,
  getGmailComposeUrl,
} from '../utils/portfolioUtils';

interface ContactProps {
  onOpenInboxModal: () => void;
}

export const Contact: React.FC<ContactProps> = ({ onOpenInboxModal }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [recipientEmail, setRecipientEmail] = useState<string>(getTargetRecipientEmail());
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastSentMessage, setLastSentMessage] = useState<RecruiterMessage | null>(null);
  const [deliveryResult, setDeliveryResult] = useState<EmailSendResult | null>(null);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);

  useEffect(() => {
    const handleRecipientChange = () => setRecipientEmail(getTargetRecipientEmail());
    window.addEventListener('portfolio_recipient_changed', handleRecipientChange);
    return () => window.removeEventListener('portfolio_recipient_changed', handleRecipientChange);
  }, []);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'Full name is required.';
    if (!formData.email.trim()) {
      errs.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errs.email = 'Please provide a valid email address.';
    }
    if (!formData.subject.trim()) errs.subject = 'Subject is required.';
    if (!formData.message.trim()) {
      errs.message = 'Please include a message or inquiry details.';
    } else if (formData.message.trim().length < 5) {
      errs.message = 'Message should be at least 5 characters long.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setDeliveryResult(null);

    // 1. Save message locally into recruiter inbox
    const saved = saveRecruiterMessage({
      name: formData.name.trim(),
      email: formData.email.trim(),
      subject: formData.subject.trim(),
      message: formData.message.trim(),
    });

    // 2. Dispatch real HTTP email to recipient using FormSubmit API
    const result = await sendEmailViaFormSubmit({
      name: formData.name.trim(),
      email: formData.email.trim(),
      subject: formData.subject.trim(),
      message: formData.message.trim(),
      targetEmail: recipientEmail,
    });

    setDeliveryResult(result);
    setLastSentMessage(saved);
    setIsSubmitting(false);
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(recipientEmail);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(PERSONAL_INFO.whatsapp);
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  const getGmailDirectLink = () => {
    if (!lastSentMessage) {
      return getGmailComposeUrl(
        recipientEmail,
        'Portfolio Inquiry',
        'Hello Abdul,\n\nI saw your portfolio and would like to connect.'
      );
    }
    return getGmailComposeUrl(
      recipientEmail,
      `[Portfolio Inquiry] ${lastSentMessage.subject}`,
      `Hi Abdul,\n\nName: ${lastSentMessage.name}\nEmail: ${lastSentMessage.email}\n\nMessage:\n${lastSentMessage.message}\n\nRef ID: ${lastSentMessage.id}`
    );
  };

  const getWhatsAppDirectLink = () => {
    if (!lastSentMessage) {
      return `https://wa.me/${PERSONAL_INFO.whatsappRaw}?text=${encodeURIComponent(
        'Hello Abdul, I saw your portfolio and would like to connect.'
      )}`;
    }
    const text = encodeURIComponent(
      `Hello Abdul, I just sent you a portfolio message (Ref: ${lastSentMessage.id}) regarding "${lastSentMessage.subject}". Message: ${lastSentMessage.message}`
    );
    return `https://wa.me/${PERSONAL_INFO.whatsappRaw}?text=${text}`;
  };

  return (
    <section id="contact" className="py-20 lg:py-28 bg-[#070B14] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 space-y-3">
          <div className="text-xs font-mono text-cyan-400 font-medium">
            Direct Professional Inquiries
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
            Get in Touch
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            I welcome discussions with recruiters, engineering managers, and technology organizations regarding Python development, IT support engineering, and technical operations positions.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: Direct Contact Details & Availability */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Contact Cards */}
            <div className="space-y-4">
              
              {/* Email Card */}
              <div className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-blue-600/10 text-blue-400 border border-blue-500/20">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs text-slate-400">Direct Email</div>
                      <a
                        href={`mailto:${recipientEmail}`}
                        className="text-sm font-semibold text-white hover:text-blue-400 transition-colors"
                      >
                        {recipientEmail}
                      </a>
                    </div>
                  </div>

                  <button
                    onClick={handleCopyEmail}
                    className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    title="Copy email address"
                    aria-label="Copy email address"
                  >
                    {copiedEmail ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                <div className="flex items-center gap-4 pt-2 border-t border-slate-800/80 text-xs">
                  <a
                    href={getGmailComposeUrl(recipientEmail, 'Portfolio Inquiry', 'Hello Abdul,')}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 hover:text-blue-300 font-medium inline-flex items-center gap-1"
                  >
                    <span>Open in Gmail Web</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>

                  <span className="text-slate-700" aria-hidden="true">·</span>

                  <a
                    href={`mailto:${recipientEmail}`}
                    className="text-slate-400 hover:text-white inline-flex items-center gap-1"
                  >
                    <span>Default Mail App</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* WhatsApp Card */}
              <div className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-emerald-600/10 text-emerald-400 border border-emerald-500/20">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs text-slate-400">WhatsApp / Direct Call</div>
                      <a
                        href={`https://wa.me/${PERSONAL_INFO.whatsappRaw}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm font-semibold text-white hover:text-emerald-400 transition-colors"
                      >
                        {PERSONAL_INFO.whatsapp}
                      </a>
                    </div>
                  </div>

                  <button
                    onClick={handleCopyPhone}
                    className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    title="Copy WhatsApp number"
                    aria-label="Copy WhatsApp number"
                  >
                    {copiedPhone ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80 text-xs">
                  <a
                    href={`https://wa.me/${PERSONAL_INFO.whatsappRaw}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-emerald-400 hover:text-emerald-300 font-medium inline-flex items-center gap-1"
                  >
                    <span>Open WhatsApp Chat</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Location Card */}
              <div className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-cyan-600/10 text-cyan-400 border border-cyan-500/20">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400">Current Base</div>
                    <div className="text-sm font-semibold text-white">
                      {PERSONAL_INFO.location}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-slate-400 pt-2 border-t border-slate-800/80">
                  <Clock className="w-3.5 h-3.5 text-slate-500" />
                  <span>Timezone: {PERSONAL_INFO.timezone} · Open to European & International opportunities</span>
                </div>
              </div>

            </div>

            {/* Recruiter Notice */}
            <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 space-y-2 text-xs text-slate-400">
              <div className="flex items-center gap-2 font-semibold text-slate-200">
                <ShieldCheck className="w-4 h-4 text-blue-400" />
                <span>Recruiter & Employer Notice</span>
              </div>
              <p className="leading-relaxed">
                Available for interviews and technical assessments. Complete academic records, official RTU thesis transcripts, and verified employment references from Euro Live Technologies can be provided on request.
              </p>
            </div>

          </div>

          {/* Right Column: Interactive Professional Contact Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-2xl bg-[#0B1120] border border-slate-800 shadow-xl space-y-6">
              
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">
                  Send a Direct Message
                </h3>
                <p className="text-xs text-slate-400">
                  Submissions are transmitted directly to <strong className="text-cyan-300 font-mono">{recipientEmail}</strong>.
                </p>
              </div>

              {lastSentMessage ? (
                /* Confirmed Sent State with Live Delivery Details */
                <div className="space-y-5 p-6 rounded-xl bg-emerald-950/20 border border-emerald-800/50 animate-in fade-in">
                  <div className="flex items-start gap-3">
                    <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-base font-bold text-white">
                        Inquiry Submitted & Delivered!
                      </h4>
                      <p className="text-xs text-slate-300">
                        Reference ID <span className="font-mono text-emerald-400 font-semibold">{lastSentMessage.id}</span> · Transmitted at {lastSentMessage.timestamp}.
                      </p>
                    </div>
                  </div>

                  {/* Delivery Status Banner */}
                  {deliveryResult && (
                    <div className={`p-3.5 rounded-xl text-xs space-y-1.5 ${
                      deliveryResult.needsActivation
                        ? 'bg-amber-950/40 border border-amber-800/60 text-amber-300'
                        : deliveryResult.success
                        ? 'bg-emerald-950/40 border border-emerald-800/60 text-emerald-300'
                        : 'bg-blue-950/40 border border-blue-800/60 text-blue-300'
                    }`}>
                      <div className="font-semibold flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Email Delivery Service:</span>
                      </div>
                      <p className="text-slate-300 text-[11px] leading-relaxed">
                        {deliveryResult.message}
                      </p>
                    </div>
                  )}

                  {/* Summary Box */}
                  <div className="p-4 rounded-lg bg-[#070B14] border border-slate-800 space-y-2 text-xs">
                    <div className="flex justify-between items-center text-slate-400">
                      <span>Sender: <strong className="text-white">{lastSentMessage.name}</strong> ({lastSentMessage.email})</span>
                      <span className="font-mono text-slate-500">{lastSentMessage.id}</span>
                    </div>
                    <div className="text-slate-300">
                      Subject: <span className="font-semibold text-blue-400">{lastSentMessage.subject}</span>
                    </div>
                    <div className="pt-2 text-slate-300 whitespace-pre-wrap border-t border-slate-800/80">
                      "{lastSentMessage.message}"
                    </div>
                  </div>

                  {/* Immediate Multi-Channel Dispatch Actions */}
                  <div className="space-y-2 pt-1">
                    <div className="text-[11px] text-slate-400 font-medium">
                      Ensure 100% receipt or send a direct notification:
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      <a
                        href={getGmailDirectLink()}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all inline-flex items-center gap-2"
                      >
                        <Mail className="w-4 h-4" />
                        <span>Open & Verify in Gmail Web</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>

                      <a
                        href={getWhatsAppDirectLink()}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all inline-flex items-center gap-2"
                      >
                        <MessageSquare className="w-4 h-4" />
                        <span>Ping on WhatsApp Directly</span>
                      </a>

                      <button
                        onClick={() => {
                          setLastSentMessage(null);
                          setFormData({ name: '', email: '', subject: '', message: '' });
                        }}
                        className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors"
                      >
                        Send Another Message
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                /* Contact Form */
                <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label htmlFor="contact-name" className="text-xs font-medium text-slate-300">
                        Your Full Name <span className="text-blue-400">*</span>
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        value={formData.name}
                        onChange={(e) => {
                          setFormData({ ...formData, name: e.target.value });
                          if (errors.name) setErrors({ ...errors, name: '' });
                        }}
                        placeholder="e.g. Noshaba Khan"
                        className={`w-full px-3.5 py-2.5 bg-[#070B14] border rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none transition-colors ${
                          errors.name
                            ? 'border-rose-500 focus:border-rose-500'
                            : 'border-slate-800 focus:border-blue-500'
                        }`}
                      />
                      {errors.name && (
                        <p className="text-[11px] text-rose-400 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          <span>{errors.name}</span>
                        </p>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label htmlFor="contact-email" className="text-xs font-medium text-slate-300">
                        Your Email Address <span className="text-blue-400">*</span>
                      </label>
                      <input
                        id="contact-email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => {
                          setFormData({ ...formData, email: e.target.value });
                          if (errors.email) setErrors({ ...errors, email: '' });
                        }}
                        placeholder="e.g. noshabakhanwebdev1@gmail.com"
                        className={`w-full px-3.5 py-2.5 bg-[#070B14] border rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none transition-colors ${
                          errors.email
                            ? 'border-rose-500 focus:border-rose-500'
                            : 'border-slate-800 focus:border-blue-500'
                        }`}
                      />
                      {errors.email && (
                        <p className="text-[11px] text-rose-400 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          <span>{errors.email}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="contact-subject" className="text-xs font-medium text-slate-300">
                      Subject / Role Title <span className="text-blue-400">*</span>
                    </label>
                    <input
                      id="contact-subject"
                      type="text"
                      value={formData.subject}
                      onChange={(e) => {
                        setFormData({ ...formData, subject: e.target.value });
                        if (errors.subject) setErrors({ ...errors, subject: '' });
                      }}
                      placeholder="e.g. Interview Inquiry: Python Developer / IT Support Engineer"
                      className={`w-full px-3.5 py-2.5 bg-[#070B14] border rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none transition-colors ${
                        errors.subject
                          ? 'border-rose-500 focus:border-rose-500'
                          : 'border-slate-800 focus:border-blue-500'
                      }`}
                    />
                    {errors.subject && (
                      <p className="text-[11px] text-rose-400 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        <span>{errors.subject}</span>
                      </p>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="contact-message" className="text-xs font-medium text-slate-300">
                      Message Details <span className="text-blue-400">*</span>
                    </label>
                    <textarea
                      id="contact-message"
                      rows={4}
                      value={formData.message}
                      onChange={(e) => {
                        setFormData({ ...formData, message: e.target.value });
                        if (errors.message) setErrors({ ...errors, message: '' });
                      }}
                      placeholder="Describe the opportunity, technical questions, or interview schedule..."
                      className={`w-full px-3.5 py-2.5 bg-[#070B14] border rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none transition-colors resize-none ${
                        errors.message
                          ? 'border-rose-500 focus:border-rose-500'
                          : 'border-slate-800 focus:border-blue-500'
                      }`}
                    />
                    {errors.message && (
                      <p className="text-[11px] text-rose-400 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        <span>{errors.message}</span>
                      </p>
                    )}
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="text-[11px] text-slate-500">
                      Delivered via FormSubmit API to <strong className="text-slate-400">{recipientEmail}</strong>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-sm hover:shadow-blue-600/30 transition-all inline-flex items-center justify-center gap-2"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isSubmitting ? 'Transmitting Email...' : 'Send Message Now'}</span>
                    </button>
                  </div>

                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
