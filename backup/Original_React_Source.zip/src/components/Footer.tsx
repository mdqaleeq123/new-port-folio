import React from 'react';
import { ArrowUp, Download, FileText, Mail, Phone, Code2 } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

import { downloadResumePdf } from '../utils/portfolioUtils';

interface FooterProps {
  onOpenResumeModal: () => void;
  onOpenInboxModal: () => void;
  onOpenCodeModal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenResumeModal, onOpenInboxModal, onOpenCodeModal }) => {
  const [isDownloading, setIsDownloading] = React.useState(false);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDownload = async () => {
    setIsDownloading(true);
    await downloadResumePdf();
    setIsDownloading(false);
  };

  return (
    <footer className="bg-[#050811] border-t border-slate-800/80 text-slate-400 text-xs py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Main Footer Row */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <div className="text-white font-bold text-sm">
              Abdul Qaleeq Mohammed
            </div>
            <div className="text-slate-400 text-xs">
              Python Developer · IT Support Engineer · Technical Operations Specialist
            </div>
            <div className="text-slate-500 text-[11px]">
              Riga, Latvia · Verified CV Profile
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-slate-400">
            <a href="#about" className="hover:text-white transition-colors">About</a>
            <a href="#skills" className="hover:text-white transition-colors">Skills</a>
            <a href="#experience" className="hover:text-white transition-colors">Experience</a>
            <a href="#projects" className="hover:text-white transition-colors">Projects</a>
            <a href="#education" className="hover:text-white transition-colors">Education</a>
            <a href="#contact" className="hover:text-white transition-colors">Contact</a>
          </div>

          <div className="flex items-center gap-2">
            {onOpenCodeModal && (
              <button
                onClick={onOpenCodeModal}
                className="px-3 py-1.5 rounded-lg bg-cyan-950/40 hover:bg-cyan-900/60 text-cyan-300 hover:text-white border border-cyan-800/50 transition-colors inline-flex items-center gap-1.5"
                title="Download Project Code & PC Installation Guide"
              >
                <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Get Code</span>
              </button>
            )}

            <button
              onClick={onOpenResumeModal}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors inline-flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>Preview CV</span>
            </button>

            <button
              onClick={handleDownload}
              disabled={isDownloading}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white transition-colors inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isDownloading ? 'Downloading...' : 'Download CV'}</span>
            </button>

            <button
              onClick={scrollToTop}
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors"
              aria-label="Scroll back to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quiet Sub-Footer */}
        <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-500 text-[11px]">
          <div>
            © {new Date().getFullYear()} Abdul Qaleeq Mohammed. Built with precision and evidence-grounded engineering rigor.
          </div>
          <div className="flex items-center gap-4">
            <a href={`mailto:${PERSONAL_INFO.email}`} className="hover:text-slate-400 transition-colors">
              {PERSONAL_INFO.email}
            </a>
            <span aria-hidden="true">·</span>
            <a href={`https://wa.me/${PERSONAL_INFO.whatsappRaw}`} target="_blank" rel="noopener noreferrer" className="hover:text-slate-400 transition-colors">
              {PERSONAL_INFO.whatsapp}
            </a>
            {onOpenCodeModal && (
              <>
                <span aria-hidden="true">·</span>
                <button
                  onClick={onOpenCodeModal}
                  className="text-slate-500 hover:text-cyan-400 transition-colors"
                >
                  Download Source Code (.ZIP)
                </button>
              </>
            )}
            <span aria-hidden="true">·</span>
            <button
              onClick={onOpenInboxModal}
              className="text-slate-500 hover:text-cyan-400 transition-colors"
            >
              Owner Portal
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
