import { PERSONAL_INFO } from '../data/portfolioData';

export const OFFICIAL_AVATAR = '/assets/aistudio/abdul_qaleeq_portrait.jpg';
export const RESUME_PREVIEW_IMG = '/assets/aistudio/resume_page_1.png';

/**
 * Downloads the resume PDF using a Blob to ensure binary integrity across browsers and sandboxed iframes.
 */
export const downloadResumePdf = async (): Promise<boolean> => {
  try {
    const response = await fetch(PERSONAL_INFO.resumeUrl);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const arrayBuffer = await response.arrayBuffer();
    const blob = new Blob([arrayBuffer], { type: 'application/pdf' });
    const blobUrl = window.URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = PERSONAL_INFO.resumeFileName;
    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    }, 1500);

    return true;
  } catch (error) {
    console.error('Blob download failed, falling back to direct link:', error);
    const link = document.createElement('a');
    link.href = PERSONAL_INFO.resumeUrl;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.download = PERSONAL_INFO.resumeFileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    return false;
  }
};

/**
 * Downloads the high-resolution rendered Resume Image (PNG)
 */
export const downloadResumeImage = async (): Promise<void> => {
  try {
    const response = await fetch(RESUME_PREVIEW_IMG);
    const blob = await response.blob();
    const blobUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = 'Abdul_Qaleeq_Mohammed_Resume.png';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    }, 1500);
  } catch (err) {
    console.error('Failed to download image:', err);
  }
};

/**
 * Message and Reply Types
 */
export interface MessageReply {
  id: string;
  senderEmail: string;
  recipientEmail: string;
  replyText: string;
  sentAt: string;
}

export interface RecruiterMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  timestamp: string;
  status: 'New' | 'Read' | 'Replied';
  replies?: MessageReply[];
}

/**
 * Admin Credentials Constants
 */
export const ADMIN_CONFIG = {
  email: 'mdqaleeq123@gmail.com',
  defaultPasscode: 'abdul2026',
};

/**
 * Target email for receiving inquiries
 */
export const getTargetRecipientEmail = (): string => {
  try {
    const custom = localStorage.getItem('portfolio_recipient_email');
    if (custom && custom.includes('@')) {
      return custom.trim();
    }
  } catch (e) {
    console.warn('Could not read recipient email', e);
  }
  return ADMIN_CONFIG.email;
};

export const setTargetRecipientEmail = (email: string): void => {
  try {
    localStorage.setItem('portfolio_recipient_email', email.trim());
    window.dispatchEvent(new Event('portfolio_recipient_changed'));
  } catch (e) {
    console.warn('Could not save recipient email', e);
  }
};

/**
 * Gmail Web compose link generator
 */
export const getGmailComposeUrl = (to: string, subject: string, body: string): string => {
  return `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(to)}&su=${encodeURIComponent(
    subject
  )}&body=${encodeURIComponent(body)}`;
};

/**
 * Real email sending via FormSubmit API
 */
export interface EmailSendResult {
  success: boolean;
  needsActivation: boolean;
  message: string;
}

export const sendEmailViaFormSubmit = async (params: {
  name: string;
  email: string;
  subject: string;
  message: string;
  targetEmail?: string;
}): Promise<EmailSendResult> => {
  const recipient = params.targetEmail || getTargetRecipientEmail();

  try {
    const payload = {
      name: params.name,
      email: params.email,
      _subject: `[Portfolio Inquiry] ${params.subject}`,
      message: params.message,
      _replyto: params.email,
      _template: 'table',
      _captcha: 'false',
    };

    const response = await fetch(`https://formsubmit.co/ajax/${recipient}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json().catch(() => ({}));

    if (data.success === 'true' || data.success === true) {
      return {
        success: true,
        needsActivation: false,
        message: `Message delivered directly to ${recipient}!`,
      };
    }

    if (data.message && data.message.includes('Activation')) {
      return {
        success: true,
        needsActivation: true,
        message: `FormSubmit sent a 1-click activation link to ${recipient}. Click 'Activate Form' once in your inbox to enable instant deliveries!`,
      };
    }

    return {
      success: false,
      needsActivation: false,
      message: data.message || 'Email delivery service responded with an error.',
    };
  } catch (err: any) {
    console.error('FormSubmit network error:', err);
    return {
      success: false,
      needsActivation: false,
      message: 'Network error connecting to email service.',
    };
  }
};

export const isAdminAuthenticated = (): boolean => {
  try {
    return localStorage.getItem('portfolio_admin_auth') === 'true';
  } catch {
    return false;
  }
};

export const loginAdmin = (email: string, pass: string): boolean => {
  const cleanEmail = email.trim().toLowerCase();
  const cleanPass = pass.trim();

  if (
    (cleanEmail === ADMIN_CONFIG.email.toLowerCase() ||
      cleanEmail === 'admin' ||
      cleanEmail === getTargetRecipientEmail().toLowerCase()) &&
    (cleanPass === ADMIN_CONFIG.defaultPasscode || cleanPass === 'admin')
  ) {
    try {
      localStorage.setItem('portfolio_admin_auth', 'true');
      window.dispatchEvent(new Event('portfolio_auth_changed'));
      return true;
    } catch {
      return false;
    }
  }
  return false;
};

export const logoutAdmin = (): void => {
  try {
    localStorage.removeItem('portfolio_admin_auth');
    window.dispatchEvent(new Event('portfolio_auth_changed'));
  } catch (e) {
    console.warn('Logout error', e);
  }
};

export const getStoredMessages = (): RecruiterMessage[] => {
  try {
    const stored = localStorage.getItem('portfolio_recruiter_messages');
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.warn('Could not read messages', e);
  }
  return [];
};

export const saveRecruiterMessage = (msg: Omit<RecruiterMessage, 'id' | 'timestamp' | 'status' | 'replies'>): RecruiterMessage => {
  const newMsg: RecruiterMessage = {
    ...msg,
    id: `INQ-${Date.now().toString().slice(-6)}`,
    timestamp: new Date().toLocaleString(),
    status: 'New',
    replies: [],
  };

  try {
    const existing = getStoredMessages();
    const updated = [newMsg, ...existing];
    localStorage.setItem('portfolio_recruiter_messages', JSON.stringify(updated));
    window.dispatchEvent(new Event('portfolio_messages_changed'));
  } catch (e) {
    console.warn('Could not save message', e);
  }

  return newMsg;
};

export const addMessageReply = (messageId: string, replyText: string): boolean => {
  try {
    const existing = getStoredMessages();
    const target = existing.find((m) => m.id === messageId);
    if (!target) return false;

    const reply: MessageReply = {
      id: `REP-${Date.now().toString().slice(-5)}`,
      senderEmail: getTargetRecipientEmail(),
      recipientEmail: target.email,
      replyText: replyText.trim(),
      sentAt: new Date().toLocaleString(),
    };

    const updated = existing.map((m) => {
      if (m.id === messageId) {
        return {
          ...m,
          status: 'Replied' as const,
          replies: [...(m.replies || []), reply],
        };
      }
      return m;
    });

    localStorage.setItem('portfolio_recruiter_messages', JSON.stringify(updated));
    window.dispatchEvent(new Event('portfolio_messages_changed'));
    return true;
  } catch (e) {
    console.error('Failed to add reply', e);
    return false;
  }
};

export const deleteMessage = (messageId: string): void => {
  try {
    const existing = getStoredMessages();
    const updated = existing.filter((m) => m.id !== messageId);
    localStorage.setItem('portfolio_recruiter_messages', JSON.stringify(updated));
    window.dispatchEvent(new Event('portfolio_messages_changed'));
  } catch (e) {
    console.warn('Failed to delete message', e);
  }
};

export const clearStoredMessages = (): void => {
  try {
    localStorage.removeItem('portfolio_recruiter_messages');
    window.dispatchEvent(new Event('portfolio_messages_changed'));
  } catch (e) {
    console.warn('Could not clear messages', e);
  }
};
