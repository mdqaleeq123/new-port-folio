# Abdul Qaleeq Mohammed — Professional Portfolio Website

A modern, high-performance personal portfolio website for **Abdul Qaleeq Mohammed** (Python Developer, IT Support Engineer, and Technical Operations Specialist). Built with **React 19**, **TypeScript**, **Vite**, and **Tailwind CSS**.

---

## 🚀 Quick Start Guide (Windows 11 / 10 / Mac / Linux)

### 1. Prerequisites
Make sure you have **Node.js** installed on your computer:
- Download and install the latest **Node.js LTS** from: [https://nodejs.org/](https://nodejs.org/)
- Verify installation by opening Command Prompt / PowerShell and running:
  ```bash
  node -v
  npm -v
  ```

---

### 2. Installation Steps

1. **Extract the ZIP file**:
   Extract all contents of `abdul-qaleeq-portfolio-source.zip` into a folder on your computer, for example:
   `C:\Users\YourName\Documents\portfolio`

2. **Open Terminal / Command Prompt**:
   - In Windows File Explorer, open your extracted folder.
   - Click the address bar at the top, type `cmd` or `powershell`, and press **Enter**.
   - *(Or open VS Code, click **File > Open Folder**, and open the built-in terminal with `Ctrl + ~`)*.

3. **Install Dependencies**:
   Run the following command:
   ```bash
   npm install
   ```
   *Note for Windows users:* If npm displays a peer dependency error (`ERESOLVE Could not resolve dependency`), run:
   ```bash
   npm install --legacy-peer-deps
   ```
   *This safely installs all packages into your `node_modules` folder without strict peer conflicts.*

4. **Start the Local Development Server**:
   ```bash
   npm run dev
   ```

5. **Open in Your Browser**:
   Open your browser and navigate to:
   ```
   http://localhost:5173
   ```
   *(Or the URL displayed in your terminal, e.g. `http://localhost:3000`)*.

---

## 🛠️ Building for Production (Deploying to Web)

When you are ready to publish the website online (e.g., to Vercel, Netlify, or GitHub Pages):

1. **Build the production bundle**:
   ```bash
   npm run build
   ```
2. This creates an optimized, static `dist/` folder ready for hosting.
3. You can test the production build locally with:
   ```bash
   npm run preview
   ```

### Free Deployment Options:
- **Vercel**: Import your GitHub repository or drag-and-drop the `dist` folder on [vercel.com](https://vercel.com).
- **Netlify**: Drag and drop the `dist` folder onto [netlify.com](https://netlify.com).
- **GitHub Pages**: Push the repository to GitHub and enable GitHub Pages on the `dist` or root branch.

---

## 📁 Project Structure

```text
├── public/
│   └── assets/
│       └── aistudio/
│           ├── Abdul_Qaleeq_Mohammed_-_Resume_57bf1a47.pdf   # Verified CV PDF
│           ├── WhatsApp_Image_2026-10-03_at_12.20.40_PM_6430b479.jpeg # Real Portrait Photo
│           └── resume_page_1.png                             # CV preview page
├── src/
│   ├── components/
│   │   ├── Navbar.tsx             # Header navigation with CV & Code download
│   │   ├── Hero.tsx               # Hero banner with portrait & terminal animation
│   │   ├── About.tsx              # Bio, profile photo & verified CV credentials
│   │   ├── Skills.tsx             # Python, SQL, IT Support & Cloud skills
│   │   ├── Experience.tsx         # Verified work history timeline
│   │   ├── Projects.tsx           # Interactive portfolio projects showcase
│   │   ├── Education.tsx          # Master's & Bachelor's degree details
│   │   ├── LanguagesStrengths.tsx # Languages & competencies
│   │   ├── Contact.tsx            # Contact form with real email delivery
│   │   ├── InboxModal.tsx         # Protected Owner Portal for managing inquiries
│   │   ├── ResumeModal.tsx        # High-definition CV viewer and downloader
│   │   └── Footer.tsx             # Footer with links and owner access
│   ├── data/
│   │   └── portfolioData.ts       # Central data file for all content & contacts
│   ├── utils/
│   │   └── portfolioUtils.ts      # PDF generation, fallback, and storage helpers
│   ├── App.tsx                    # Main application root
│   ├── index.css                  # Tailwind CSS configuration
│   └── main.tsx                   # React DOM entry point
├── package.json                   # Dependencies and npm scripts
├── tsconfig.json                  # TypeScript compiler options
└── vite.config.ts                 # Vite build configuration
```

---

## 🔐 Credentials & Contact Configuration

- **Owner Portal Login** (for viewing recruiter messages):
  - **Email**: `mdqaleeq123@gmail.com`
  - **Passcode**: `abdul2026`
- **Contact Form Delivery**:
  - Automatically routes form submissions directly to `mdqaleeq123@gmail.com` using the FormSubmit service.
- **Updating Your Information**:
  - Edit `src/data/portfolioData.ts` to update any bio text, phone numbers, LinkedIn URL, or project details.
